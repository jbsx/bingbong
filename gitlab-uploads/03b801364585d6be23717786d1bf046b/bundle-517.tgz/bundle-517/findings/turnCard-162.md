---
test: e2e/turnCard.e2e.test.ts:127
slug: turnCard-162
status: not-reproduced
class: stale-test
cause_key: #507's Loading row made a failed play seven steps, so its Heard row rolls off the six-row history before the Failed state is drawn; f2c21d13 already dropped the assertion, and with it the only guard on the second line's Heard row
same_as: none
---

# The Turn Card e2e no longer checks that a second line draws its Heard row: the assertion that went red was dropped, not replaced

Part of #517.

The test, not the app, and the red itself is already gone: the file passes at `c35c75b1`, because `f2c21d13` deleted the failing assertion. That assertion expected `Heard“play nothing at all”` on the ended card, which nothing promised: the card's history is six rows and rolls its oldest off. Since `40cd2aee` (#507) a failed play has seven steps, so Heard is the one that rolls. The person loses nothing, because the Thinking row still on that card carries the same words at the same moment. What the deletion did lose is a guard: nothing now checks that the second line of a Hot Listen draws its Heard row at all. This issue puts that check back in a form that does not depend on the row count. Test change only.

**Scenario:** play (yield 20, `partly`, names misheard, per `docs/agents/yield.md`). Also the Receipt on every spoken line from the Idle Screen (#474, ui.md 1). No change to the scenario or its state. It restores the e2e guard on the Heard row of a line after the first.

## Root cause

1. The history is a sliding window of six rows: `turnHistory` takes `state.steps.slice(-rows)` with `TURN_HISTORY_ROWS = 6` (`src/core/idle/turnCard.ts:445-448`). That is the design: #474 and CONTEXT.md's Turn Card entry say "six fixed rows of history, oldest first", and `src/core/idle/turnCard.test.ts:327` already expects Listening and Transcribing to have rolled off a finished line.
2. Before `40cd2aee`, a play that found nothing had exactly six steps from Heard on: Heard, Thinking, Read as, Playing, Speaking, Failed. Heard just fitted, so the assertion passed by count, not by promise. This list is by count: that run is green with the assertion in it (below), but vitest printed no card text for a passing run.
3. `40cd2aee` (#507, 2026-10-29, the commit's "Review fixes") opens the song's wait before the results fetch, as the Receipt over a 0.8 s search. It is now at `src/main/music/player.ts:1251`: `tellWait({ kind: 'lookup', song: { title: words }, ... })`. The runner turns that into a `loading` status (`src/main/run/commandRunner.ts:2136`), and the fold adds a Loading row. This is intended.
4. A failed play now has seven steps. Heard rolls off before Failed is drawn, and `expect(seen.states.failed?.text).toContain('Heard“play nothing at all”')` (line 162 at `4ba056aa`) goes red.
5. `f2c21d13` (2026-10-30 11:29) deleted that line and said why in its message. Its reasoning holds, but it put nothing in the line's place. The Heard check that remains (`expect(seen.states.thinking?.text).toContain('Heard“what a lovely day”')`, now line 172) reads the first line only, and `heardShownAt` / `heardAt` in `WATCH` record only the first too. A regression that lost the Heard row from the second line on would pass.

#517's lead that the voice commits (`f3712c4e`, `087b4ed3`, `4ba056aa`) might be behind this is refuted: `40cd2aee` is an ancestor of all of them and is already red.

## Evidence

All under Xvfb on the scripted stand-in. The file holds one test, so whole file and `-t` alone are the same run. No real host or Jev was reached.

| Run | Tree | Result |
|---|---|---|
| Reproduction | `c35c75b1`, unchanged | **0 red of 3**. `4ba056aa` itself was not rerun; #517's red is reproduced by the next rows |
| Bisect, before | `40cd2aee^`, its own test (old assertion in it) | green, 1 of 1 |
| Bisect, at | `40cd2aee`, its own test | red, 1 of 1, #517's exact error |
| P1 | `c35c75b1` + old assertion put back | red, 1 of 1, #517's exact error |
| P2, the flip | P1 + `player.ts:1251` deleted | green, 1 of 1 |
| P3, candidate guards | `c35c75b1` + both guards below, soft | green, 3 of 3, both guards |
| P4, do they bite | P3 + the second line's Heard row relabelled and its Thinking text blanked in the fold | red, 1 of 1, **both** guards fail |
| Final | `c35c75b1` + the patch | green, 1 of 1 |

The app's own card, from P1 (and identical at `40cd2aee`):

- States: `listening → transcribing → thinking → dropped → loading → failed`
- `failed`: `2.9s Thinking“play nothing at all” · Read as play nothing at all · Playing nothing at all · Loading finding the audio for “nothing at all” · Speaking No videos found… · Failed No videos found…` (six rows, no Heard)

Each of the 3 reproduction runs also passed what `f2c21d13` added. The P4 run printed the bar off its close by at most 0.002 over 134 samples. The flip in P2 is the one deleted line in link 3 and is **not** a suggested fix: it would take away #507's Receipt.

**Arms for the replacement guard.** This is a test-only fork, so the owner would not feel it and no measure is owed. Both were measured anyway because it was cheap.

| Arm | Assertion | P3 | P4 | If one more row joins this road |
|---|---|---|---|---|
| H (kept) | The `WATCH` records every Heard row as drawn; `seen.heardRows` equals both lines' words | 3 of 3 | red | stays green (by reading the window; not run) |
| T | `failed` contains `Thinking“play nothing at all”` | 3 of 3 | red | goes red for the same design reason this one did (not run) |

They measure the same, so H wins on what it asserts: it is #474's AC1 ("the final transcript appears in the Heard row") for every line, and it does not repeat the fault of counting rows.

## The change

`e2e/turnCard.e2e.test.ts` only. The diff is saved at `/home/jbsx/.claude/jobs/7b9f65fd/tmp/findings/turnCard-162.patch`:

- `WATCH`: add `heardRows: []` to `window.__turn`. In `grab`, before `const state = card.dataset.state`, walk `.turn-step` and push each row's `.turn-step-text` when its `.turn-step-label` is `Heard` and the text is not already there. This must stay before that line's `return`-guarded state capture, so that a repeat state still records rows.
- `Seen`: add `heardRows: string[]`.
- Where the old assertion stood, before `expect(seen.states.failed?.text).toContain('Read asplay')`: add ``expect(seen.heardRows).toEqual([`“${NONE}”`, `“${PLAY}”`])`` with a comment saying it is read as drawn, because a line with more steps than six rows rolls its oldest off.

No `src/` change. No new stage, wait, state, word or sentence, so no Tier or UI principle moves, and the input-to-output chart does not change.

## Acceptance criteria

- [ ] `e2e/turnCard.e2e.test.ts` passes on the shipped road, with no switch set and the #507 Loading row in place.
- [ ] It asserts that both lines drew their Heard row, read from the rows as drawn, not from the text of any one state.
- [ ] It does not assert `Heard“…”` on the `failed` state.
- [ ] With the second line's Heard row removed in the fold (throwaway), the test goes red.
- [ ] No file under `src/` changes.

## Not in this issue

- The Heard row's own timing on the second line: `heardShownAt` still records the first line only. AC1's 100 ms stays measured on that one.
- `turnCard.ts:267-276`: the `heard` IPC can trail a fast line's run and is slotted in before that line's rows. On a line already past six rows it would never be drawn, and the new guard would go red. That would be a true report that the Receipt row never showed, so it is left to fail. It did not happen in 4 of 4 runs here; it was not stressed under load.
- A page-card line that fails would by count have Thinking at the page, Read as, the action, Loading, Speaking and Failed, leaving the heard words off the ended card altogether. This is by reading the fold only, not observed, and no ledger line reports it.
- On every failed line the Speaking and Failed rows carry the same sentence, and so take two of the six rows.

## Dependencies

None. Open issues read (`open.txt`): #518, #517, #516, #512, #490, #469, #452, #439, #415. None blocks or is blocked by this.

## Grill

Answered from the sources named, as the brief asks. Nothing was put to the owner.

- **Is this an app bug: did the app lose behaviour the test guarded?** No. #474's AC1 asks for the transcript in the Heard row when it lands, and for Done or Failed to be the last rows. It never asks for Heard to survive to the end. CONTEXT.md and `turnCard.test.ts:327` make rolling off the design.
- **Does the person lose the words?** No, not on this line. The Thinking row on the same ended card has them (`failed` above), and ui.md 1's Receipt is a within-100 ms promise that the first line's check still measures.
- **Should the row count go to seven, or Heard be pinned?** No. "Six fixed rows" is #474's, from the owner's chosen prototype, and "nothing moves" is the owner's ruling of 2026-10-26. No report asks for it. Reopening it would answer a test, not a scenario.
- **Should the Loading row go on a play that finds nothing?** No. It is #507's Receipt over a 0.8 s search, measured in that commit. P2 shows that removing it turns the test green, and that is exactly why it is not the fix.
- **Was `f2c21d13` wrong to drop the line?** Right to drop it, incomplete in not replacing it. The commit message's reason matches links 1-4.
- **Why file anything, if the test is green?** A test that guards less than it did is what #517 is looking for: AC1 is now unguarded on any line after the first.
- **Keep arm T as well?** No. It would redden on the next added row for no fault, the same way this one did. H alone covers AC1.
- **Does `heardRows` need to record the partials or row times?** No. AC1 here is that the transcript was drawn. Timing stays on `heardShownAt`.
- **Is the `toEqual` order safe?** Yes. Lines run in order, and the `WATCH` records a row the first time it is seen.
- **Does a fix need a Yield or Tier statement?** Yield is above. Tier: no stage added. UI: nothing added. Chart: not affected. CONTEXT and ADRs need no wording.
- **Does this overlap `idle-221`, which is also about the Turn Card?** No. That one is the fold staying open after a wake and taking a tap; this test never reaches it.
