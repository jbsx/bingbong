---
test: e2e/hotListen.e2e.test.ts:56
slug: hotListen-56
status: confirmed
class: stale-test
cause_key: the test feeds frames by hand with no mic, so the failed capture disarms the listen; and it waits for the rest hint, which #436 gave to the last spoken result
same_as: none
---

# e2e/hotListen's two-Utterance test runs with no mic, so a failed capture closes its listen, and it waits for a rest hint that #436 replaced

Part of #517.

The test is wrong and the app is right. The app takes two Utterances on one wake and closes 8 s after the last Command ended, as CONTEXT's **Hot Listen** says, once its capture is open. Two separate faults stack up in the test. The first hides the second, so fixing only the one #517 reports leaves the test red. Test change only, nothing under `src/`.

**Scenario:** `wake` (the first line after wake), yield 5, state `slow` (spoken sessions 2026-10-22 and 2026-10-23 in `docs/agents/yield.md`). This does not change what the owner hears or the scenario's state. It puts back the e2e guard on one wake, two Commands, closed by silence. That guard has not held since at least #436 (2026-10-26).

## Root cause

**Fault 1: red at `:56` (the orb's wait), no mic.**

1. Agent sessions run with `PULSE_SERVER=unix:/nonexistent` (`.claude/settings.json`, 9578a918, 2026-10-23, the off-screen mute). Under it, `getUserMedia({audio: true})` in the dashboard rejects after 263 ms with `NotReadableError: Could not start audio source` (direct probe).
2. The test launches with no fake mic and feeds frames by hand with `sendAudio`. The wake still fires, because the frames reach the scorer.
3. Opening the listen makes `useVoice` start capture (`src/renderer/src/useVoice.ts:136`). The capture fails and its catch calls `voice.disarm()` (`useVoice.ts:113`), which is `stopListening` (`src/core/voice/voiceSession.ts:834`).
4. The state walk shows the listen open at 5 ms and closed with `reason: null` at 200 ms. The orb's `waitFor` polls every 250 ms, so it usually misses the window. That race is the `:56` timeout in #517. The test's sibling (#483) already records this in a comment: "a manual sendAudio walk is disarmed by the failed capture under an agent's muted audio". The sibling got the fake mic and this test did not.
5. Winning the race does not help. At a 20 ms poll the burst gets both lines into the Feed, but the listen still closes at 234 ms, by the disarm and not by silence. So under a dead mic the test's "closes on silence" step could not prove silence at all.

**Fault 2: red at `:74` (the last wait), the rest hint.**

6. Since 9db2d2ba (#436, 2026-10-26) the capsule's hint holds the last spoken result in place of the rest hint (`src/core/voice/voiceHint.ts`, `result` is checked before `monitoring`). This is deliberate: the commit says so and `src/core/voice/voiceHint.test.ts:59` pins it ("keeps the last spoken result in place of the wake instruction").
7. The test ends by waiting for `.voice-hint--monitoring`, after two Commands that each said something. That element cannot appear, so the wait times out with the ear correctly back: `{listening: false, reason: null, monitoring: true}`, and the pill says Ready.

The sibling test passes because it runs no Command, so there is no result to hold the hint.

## Evidence

All at `c35c75b1`, under Xvfb, on the scripted stand-ins. No model is reached.

| Run | Result |
|---|---|
| Unchanged, whole file | red 3 of 3, all at `:56`; the sibling test green each time |
| Unchanged, alone | red 3 of 3: 2 at `:56`, 1 at `:74` (it won the race) |
| Unchanged walk, watched, feeding 12 frames | listen open 5 ms, closed 200 ms |
| Arm: dead mic, 20 ms poll | past the orb, both lines in the Feed, closed at 234 ms by the disarm, then red at the hint |
| Arm: unchanged walk with a working mic, a private null-sink PulseAudio room (`openReplayRoom`), nothing reaches a speaker | past `:56`; last Command ended 3041 ms, closed 11046 ms (8.0 s); red only at the hint. Flips Fault 1 without the fake mic |
| Arm A: fake mic, no hand feed | same 8.0 s close; second line `Scrolling down`; red only at the hint |
| Arm B: fake mic, hand feed kept | same 8.0 s close; second line answers `There's no page open.`; red only at the hint |
| Flip, Fault 2: Arm A with the old hint wait and `result: null` in `App.tsx:169` | green |
| Same, `App.tsx` restored | red at that hint wait |
| **The change below, whole file** | **green 3 of 3, both tests** |
| **The change below, alone** | **green 1 of 1** |
| Negative control: the change's new assertions, no mic, burst and 20 ms poll | red at the `listen-closed` wait: a disarm writes no span |

The unchanged file ran again after the flips only in the `App.tsx`-restored form above. The six unchanged runs in the first two rows are the red baseline. `pnpm typecheck` is clean with the change.

**Not run:** any base commit. `PULSE_SERVER` dates Fault 1's conditions for agent sessions, but a 2026-10-23 note records this file already red on `origin/main` as that mute landed, so Fault 1's true start is not bisected. #517's own run does not record its environment. A shell with a live PulseAudio would open the machine's real mic and escape Fault 1, and I did not run that because it is the road the mute rule closes. Fault 2 reaches any environment. Neither gap changes the fix: the fake mic makes the test independent of the session's audio. The disarm's catch was not logged directly, because renderer faults only reach the console (`src/renderer/src/diagnostics.ts`). The chain rests on the direct `getUserMedia` rejection and on the room arm, where a mic that opens is the only change and the disarm goes.

**Arms for how frames arrive** (a test-shape fork, recorded because it was measured): the measure was this test's walk and the Feed's second line. A wins. Its second Command runs on the landed page (`Scrolling down`), at the capture road's own pace, while B's burst lands inside the first Command's load and answers wrongly. Both close at 8.0 s.

## The change

`e2e/hotListen.e2e.test.ts`, first test only. The saved patch is exactly this:

- Add `const FAKE_MIC = ['--use-fake-device-for-media-stream', '--use-fake-ui-for-media-stream']` and pass `launchArgs: FAKE_MIC`.
- Remove the `feed` helper and both calls. The scripts advance at the mic's pace, and the choreography is unchanged.
- Rewrite the header comment's last sentence to match: the capture graph feeds the scripts.
- Raise the orb's wait to 30000 ms, the sibling's bound for a fake mic.
- Replace the final `.voice-hint--monitoring` wait with:
  - a wait for `getState().listening` false;
  - `expect(state).toMatchObject({ listening: false, reason: null, monitoring: true })`;
  - a wait for the `listen-closed` perf record, as the sibling does, with `toHaveLength(1)` and `detail` matching `{ reason: 'wake', heard: true }`. The session writes that span only when the silence bound runs out (`voiceSession.ts:390`), so it proves the close was silence and not a disarm, and `toHaveLength(1)` that one wake stood the whole way.
- Pass a test timeout of `120_000`, as the sibling does.

## Acceptance criteria

- [ ] `takes two Utterances as two Commands after one wake, then closes on silence` passes on the shipped road, with `BINGBONG_WAKE_ENGINE=node` and the three scripts, through Chromium's fake mic, with no `sendAudio` in the test.
- [ ] It passes whether or not `PULSE_SERVER` points at a live server.
- [ ] It asserts the close by the `listen-closed` span `{reason: 'wake', heard: true}`, length 1, and goes red under a failed capture.
- [ ] It does not wait on `.voice-hint--monitoring`. `voiceHint.test.ts:59` keeps guarding #436.
- [ ] The commit names both reasons: the failed capture's disarm, and the rest hint given to the result by #436.
- [ ] No file under `src/` changes.

## Not in this issue

- **The capsule says Ready with no mic.** Under `NotReadableError` the capsule read `Ready · Say "Bing Bong" or start typing`, and `feedText` was empty. The `failed` ear phase (#447) covers a model that will not load, not a capture that will not open. That bends the Glance surface's first job, "whether speaking now will be heard". It is a real gap on any machine whose mic goes away. No spoken line shows it yet, so it is not filed here; it belongs in the ledger if the kiosk ever shows it.
- **`e2e/oneAsk` and `e2e/paneTiming` still hand-feed under a dead mic.** `paneTiming`'s comment says it knows. `oneAsk` got through #517 by getting its burst in before the disarm, on the same race as Fault 1 with a 100 ms poll. Same exposure, not red today.
- **The burst's `There's no page open.`** in Arm B: a line 1 ms after a navigate, while it loads. Only the burst produced it, no real line. `overlap` owns that road if a real one does.
- **`This page shows no text.`** on the fixture's `/` after the navigate lands. Seen in every arm's Feed and not looked at.

## Dependencies

No genuine edges. Read the open issues: #518, #517, #516, #512, #490, #469, #452, #439, #415. Nothing here waits on them, including #490's over-speech work, and this blocks none of them.

## Grill

Answered from the rules, on the owner's behalf.

- **Is the app or the test wrong about the hint?** The test. #436's commit and `voiceHint.test.ts:59` make the result-over-rest order deliberate. The pill still says Ready, so the Glance surface's job holds.
- **Is the disarm on a failed capture an app bug?** Not for this test. CONTEXT's Hot Listen lists disarm as a close, and no words can arrive without a mic. What the screen says at that moment is a separate gap, listed above.
- **Why not just poll faster at `:56`?** It flips the line and proves nothing: the 20 ms arm shows the listen closed by disarm at 234 ms. The test would pass a close it never measured, and would not reach the silence bound.
- **Why not have the test use a live PulseAudio room?** The room arm goes past `:56` too, but the fake mic is the suite's recipe (#442, #444, #483, `hotListenCapsule`) and needs no daemon. It is decided by the code beside it, so it is not a tie.
- **Fake mic with or without the hand feed?** Measured above: without.
- **Which final assertion?** State plus span. A bare `.voice-hint--result` wait would pass under a disarm too, and the negative control shows the span goes red there. The hint's rule stays with its unit test.
- **Should the test assert the second line's outcome (`Scrolling down`)?** No. The title's claim is two Commands from one wake, and the Feed's two lines and one span carry it. What a scroll says belongs to the scroll tests.
- **Does the Hot Listen's 8 s need checking in this test?** No. The span's `heard: true` proves which road closed it. The sibling bounds the time for a wake with no words. The arms here measured 8.0 s, for the record.
- **Does this add a stage, a wait, a state, a word or a sentence?** No. There is no Tier or Felt Reaction to state, no UI principle in play, and the input-to-output chart does not change.
- **Is a ledger line owed?** No. No line failed; this is a guard that broke. The ledger takes lines that did not do what was meant.
