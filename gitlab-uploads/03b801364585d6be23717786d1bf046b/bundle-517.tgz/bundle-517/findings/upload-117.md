---
test: e2e/upload.e2e.test.ts:117
slug: upload-117
status: confirmed
class: stale-test
cause_key: since #485 a line the Local Match cannot settle is asked on the Appliance Card first, so a decisionScript in page-card labels has its entry consumed by the Appliance Card ask, which reads malformed
same_as: upload-103
---

# e2e/upload still scripts the page card: the "attach a photo of me" proof for `upload-103`

Part of #517. Same cause and same change as `upload-103`, whose body stands. This file holds the proof for line 117 and the one thing this test adds. The test is out of date and the app is right: with the script corrected, the button over the hidden field opens its chooser and the photo lands on that field.

**Scenario:** as `upload-103`: no upload row on the Yield list, nearest `goal` (yield 4, `partly`, `pnpm goal:gate` 2026-10-27). No change to any scenario or its state. It restores the e2e guard on the hidden-field road (#424, ADR 0092), which has guarded nothing since #485.

## Reproduction

All at `c35c75b1` under Xvfb on the scripted stand-in. Nothing reached a real host: the suite sets `BINGBONG_DECISION_SCRIPT`, and the fixed run's Shelf pick records `"model":"scripted"`. The failure is the same as #517's at `4ba056aa`: line 117, `waitFor` timeout of 20000 ms. Line 117 waits in `cli()` for `/^(clicked \[2\]|error:)/`, and the app never prints either.

The kept-log runs carried one throwaway line in `afterAll` that copied the logs out, which moved the failing line to 118. It is not in the patch.

| Run | Alone (`-t 'attach a photo of me'`) | Whole file |
|---|---|---|
| Unchanged | red 1 of 1 | red 1 of 1 (4 failed, 1 passed) |
| `upload-103`'s patch + this test's asserts | green 2 of 2 | green 2 of 2 (5 passed) |
| Same, with only the photo line's `page` entry removed | red 1 of 1 | red 1 of 1 (**this test alone red**, 4 passed) |
| Final patch, with the Shelf ask assert | green 1 of 1 | green 1 of 1 (5 passed) |

No flake: every run went the way its script predicts, and alone and whole file never differed. `pnpm typecheck` and eslint on the patched file pass.

**Start of the failure, unchanged test built at each commit, alone:**

| Commit | Result |
|---|---|
| `7f1eab55` (parent of #485) | passed |
| `a2297959` (#485) | failed, 20 s timeout |

## What the app did on this line

The chain is `upload-103`'s, read here from this line's own records. The record below is from the whole-file run; the alone run differs only in its ask id (`cli-2-…`).

1. `commandRunner.ts:1479` asks the Appliance Card first. That ask takes the line's entry 1, `click-2`, and reads `malformed`, since that card has no such option.
2. `commandRunner.ts:1358` goes on to the page card, whose ask takes entry 2, the one meant for the Shelf: `action: none`.
   `{"reading":"jev","verb":"none","card":"page","appliance":{"ask":"cli-3-mvvbovml-appliance","jev":{"reason":"malformed"}}}`
3. A hop-0 `none` asks again (`commandRunner.ts:1601`, ADR 0082). That `-where` ask finds the script empty and the line ends `unavailable`.
   `{"reading":"best_guess","verb":"none","ask":"cli-3-mvvbovml-where","jev":{"reason":"failed"},"ended":"unavailable"}`
4. Nothing was clicked. The asks for the line are `appliance`, `command`, `where`, with no `shelf`, and no ask carries `fate`.

With the fix the record reads:
`{"reading":"jev","verb":"click","card":"page","target":2,"ended":"terminal","appliance":{"chose":"page"},"upload":{"file":"me.png","shelf":3,"ask":"cli-2-mvvbqr45-shelf"}}`, with asks `appliance`, `command`, `shelf`.

The page card lists `[1] file field "Attach a document"`, `[2] button "Add a photo"` and `[3] button "Send"`. The hidden field has no ref of its own, so ref `[2]` is the button, and the file landing on `photo` shows the chooser came from the button's click.

**Why the test and not the app:** ADR 0096 rules the Appliance Card first; the road past it is unchanged, as the green runs show.

## What this test adds to `upload-103`'s change

The script change is already in `upload-103`, including `readingOf(LINES.photo, 'page')`; without that entry this test stays red, as the third row shows. Patch: `findings/upload-117.patch`. It applies alone on `c35c75b1` and contains all of `upload-103.patch` plus the two edits below, so a builder applies this one instead of both.

In the `attach a photo of me` test, `e2e/upload.e2e.test.ts`:

- Line 118: expect `{ ended: 'terminal', card: 'page', appliance: { chose: 'page' }, upload: { file: 'me.png', shelf: 3 } }`.
- After it, read the asks log and expect one Shelf ask for the line whose state contains `accepts "image/*"`, so the hidden field's own `accept` reaches Jev:

```ts
const asks = await logLines<{ kind: string; state: string }>(userDataDir, 'asks-')
const shelf = asks.filter((ask) => ask.kind === 'shelf' && ask.state.includes(LINES.photo))
expect(shelf).toHaveLength(1)
expect(shelf[0]!.state).toContain('accepts "image/*"')
```

No stage, wait, word or sentence is added, so no Tier, UI or chart change applies.

## Acceptance criteria to add

- [ ] The photo test passes with the Appliance Card on, whole file and alone.
- [ ] It asserts the Appliance Card's `page` pick, the page card's click, `me.png` on the `photo` field, nothing submitted, no OS dialog, and one Shelf ask carrying `accepts "image/*"`.

## Not in this issue

- The Shelf ask's sentence does not parse for a field with no label: `The page opened its file chooser for its file field accepts "image/*": …` (`src/core/command/shelfAsk.ts:44`, read from this run's asks log). The wording is on Jev's card, so changing it is a gate question.
- `attach a photo of me` has no corpus case on any card, so the scripted `page` and `click-2` say nothing about what a real model picks. `upload-103` notes this too.

## Dependencies

No blocking edges. I read the open issues on 2026-10-30 (#518, #517, #516, #512, #490, #469, #452, #439, #415): none blocks this.

## Grill

The named `grill-with-docs` skill is not available in this session. I loaded `mattpocock-skills:grilling` and answered its questions myself, as the brief says.

- **Does a hidden field need a different fix from a visible one?** No. The third row flips on the Appliance Card entry alone, and the chooser road is green without any `src/` change.
- **Is the shared cause proven here, or inherited?** Proven here: this line's records, the base pair built and run alone, and a flip that turns only this test red.
- **Should the record also assert `target: 2`?** No. `DecisionLine` would grow another field for what `{ id: 'photo' }` on the change already proves.
- **Is the Shelf ask assert in scope?** Yes. It is what is particular to this test and passes in the final runs. It pins only the `accepts "image/*"` words, so rewording the sentence around them does not break it.
- **`page` or `none` on the Appliance Card?** `page`, settled in `upload-103`. The test does not depend on the difference.
- **Does a tie need measuring?** No. Nothing here changes what the owner hears or how fast.
- **Is `HANDOFF.md` a handoff for this test?** No. The file at the worktree root is the orchestrator's from main (`bfd8b13e`), and no handoff commit sits on this branch. It stays, per the standing rule never to remove it from main.
