---
test: e2e/loadingPage.e2e.test.ts:81
slug: loadingPage-81
status: confirmed
class: stale-test
cause_key: since #485 (a2297959) an exact line fires on its words with no page collect, so `click 999` is never still being read when the next line arrives, and the test's abandoned reading cannot happen; the road it guards needs a free-words line
same_as: none
---
# e2e/loadingPage's order test gives an exact line, which since #485 fires at once, so it no longer reaches the abandoned reading it guards

Part of #517.

The test is out of date; the app does what the owner ruled. The test gives `click 999` and expects it to be abandoned while it is read. That relied on the exact line waiting on the page collect, which held it for the 12 s load. Since #485 an exact line fires on its words (reliability.md rule 1, AGENTS.md Reliability), so there is no read left to abandon. What the test guards is still real and still ships: a line still being read when a later line takes the pane fires nothing, says why, and is filed where it was given. It has to be reached with a line that really is being read. Test change only; no file under `src/` changes.

**Scenario:** overlap, yield 20, state `partly` (17/26 Sequence Cases on Jev, `pnpm overlap:gate --with-jev --road audio`, 2026-10-29, docs/agents/yield.md). This changes nothing the owner hears, and the scenario's state stays. It restores the guard on "replace it" while the first line is still being read, the case where a slow read would otherwise fire after the line that replaced it and cancel it (ADR 0076, "Superseding reaches the reading"). The e2e is the only guard on this with the Appliance Card on: every unit test of the `abandoned:` words (`src/main/run/commandRunner.test.ts:1922`, `1944`, `1965`, `1985`, `3817`) runs on a harness with no card, which is `BINGBONG_APPLIANCE_CARD=off`.

## Root cause

1. The test gives `click 999` over a loading page (`e2e/loadingPage.e2e.test.ts:76`) and expects `abandoned: a later Command came first` (`:83`). Added in `c3bc2414` (#330), when "every page collect waits for a navigation under way to commit and land first". The click was held on that collect, and the next line abandoned it.
2. `a2297959` (#485, 2026-10-27), by design: "an exact line fires on the page in hand, never a collect… with none in hand the line fires". The code is `src/main/run/commandRunner.ts:1335-1341`.
3. So `click 999` fires about 200 ms after the navigate. Its record is `reading: local_match`, `verb: click`, `jevAsked: false`, and the Feed shows `click 999click [999]`.
4. The later `navigate /second` then ends it as an action in flight, not as a reading (`commandRunner.ts:1172`, `1186`, `1019`, ADR 0097 "Exact lines keep firing on their words"). The Answer is "Stopped clicking item 999.".
5. The test never learned this. `a1343fef` (#514) only swapped its third line from `read` to `navigate`, and its message says `click 999` "ends on its own before the next line arrives". The Feed from this run shows otherwise: it did not end on its own, the next line stopped it. The red it recorded was this same cause.

The first thing wrong is the test's choice of line (link 1), judged against the ruling in link 2. Nothing in the owner's rulings, ADR 0097 or CONTEXT.md says an exact line should wait to be read.

## Evidence, at `c35c75b1` under Xvfb, scripted stand-in only

- **Reproduction, unchanged file:** red 2 of 2 whole file, red 2 of 2 alone, always line 81. Same failure as #517 at `4ba056aa`, except the third entry is now `navigate …/second` instead of `read`:
  ```
  - StringMatching /^click 999abandoned: a later Command came first$/
  + "click 999click [999]"
  ```
- **What the app did:** see links 3 and 4. Decision records are from `<userData>/logs/decision-*.jsonl`, the Feed from `feedDisplays`.
- **Bisect, each commit with its own test file, alone:**
  | commit | result |
  |---|---|
  | `7f1eab55` (`a2297959`'s parent) | passes |
  | `a2297959` | fails, this diff |
  | `8082ab7d` (parent of #489's `136cb98b`) | fails, this diff |

  So #485 turned it red. #489 ("arrival ends nothing") came later and did not cause it.
- **Probe flip (`loadingPage-81.patch`):** green 5 of 5 tests in 2 of 2 whole-file runs, and 3 of 3 alone. Three earlier whole-file runs of a near-identical draft were also green. Revert the patch and it is red again at line 81, whole file, 1 of 1.
- **The guard is real (mutation):** with the patch on and `commandRunner.ts:3360` changed to `if (false as boolean)`, so an ended reading fires, the test goes red: `+ "navigate …/second"`, `+ "take me homesay the time"`. Restoring the line turns it green.
- **An early draft was green for the wrong reason:** a scripted `search` is not on the Appliance Card, and no `fate` was scripted, so the answer read `malformed` and the Feed assertions still passed. The Feed alone cannot tell these apart, which is why the record assertions below are required.
- Test time goes from 1.9 s to about 4.7 s, because the stand-in holds its answer for 3 s.
- Not run: `pnpm test` and typecheck on the patch, and any other e2e file. No paid model was used.

## The change

`loadingPage-81.patch` is the whole change; apply it as it stands.

`e2e/scriptedJev.ts`:
- Add an optional `fate?: 'ends' | 'joins' | 'waits' | 'goes_on'` to `Reading` and to `readingOf`'s `more`.
- Emit `fate: choice(reading.fate)` only when it is set.

The card asks `fate` over a running line (`src/core/command/applianceCard.ts:313`) and `readDecisionAnswers` needs every question answered (`src/core/ports/decisionModel.ts:198-201`). So today any scripted line over a running one reads `malformed`, and no e2e file scripts a `fate`. Leaving it optional keeps every other suite's script byte for byte.

`e2e/loadingPage.e2e.test.ts`, same title:
- `startHarness({ env: decisionScript(readingOf('take me home', 'say_time', { delayMs: 3_000, fate: 'goes_on' })) })`. The other four tests use exact lines only and stay green under it.
- Give `take me home` where `click 999` is; expect `take me homeabandoned: a later Command came first`; keep `muted` `[false, true, false]`.
- The third line stays a `navigate`. It must take the pane: a `scroll down` goes on beside the read and abandons nothing (ADR 0097).
- Assert the record: `{ reading: 'jev', card: 'appliance', ended: 'superseded' }`, and no `jev.reason`.
- Assert that the last two Feed displays are `Stopped.` and `Opened …/second.`, so `say_time`'s Answer never shows.

Why these values:
- `take me home` is the words the runner's unit test already uses (`commandRunner.test.ts:1974`), and no grammar reads it.
- `say_time` is on the Appliance Card and would visibly fire if the guard broke.
- `goes_on` is the card's default reading of a Fate (ADR 0097, "Unsure is `goes_on`"). The read never reaches it here, because the line has already ended.
- 3 s is a guess, marked so in the code: long enough that the next line lands inside the read on a loaded machine (0.7 s measured between the two lines here), and short enough for the test. If it ever flakes, raise it; the test already allows `HELD_RESPONSE_MS + 5 s`.

No Command's path gains a stage, so no Tier changes. There is no new wait, state, word or sentence in the app, and the input-to-output chart is not affected.

## Acceptance criteria

- [ ] The test passes with the Appliance Card on and the scripted stand-in, whole file and alone; `BINGBONG_APPLIANCE_CARD` is not set.
- [ ] The abandoned line is a real read: the record has `card: 'appliance'`, `reading: 'jev'`, `ended: 'superseded'`, and no `jev.reason`.
- [ ] The Feed has it greyed and between the two navigates, though it is published after the second; `say_time`'s Answer does not show.
- [ ] Making an ended reading fire (`commandRunner.ts:3360`) turns the test red.
- [ ] The other four tests in the file still pass.
- [ ] The commit names the reason: the expectation went out of date with #485.
- [ ] No file under `src/` changes.

## Not in this issue

- **Wrong sentence on a Feed entry, app, not fixed:** when a pane-taking line ends several Commands in flight, `cancelInFlight` gives each the running line's sentence (`commandRunner.ts:997-1000`). In the unchanged test's Feed, "Stopped clicking item 999." shows twice, and the second copy can only be the held navigate's, which was never clicking. Seen in the Feed only; not checked whether it is also said twice.
- **Other reds in #517** are their own findings. Any suite that scripts a line over a running one will need the new `fate` field.
- **`HANDOFF.md`:** the one at this worktree's root is main's music-pass handoff, not this job's, so it was left in place.

## Dependencies

Blocked by nothing. #518 touches a different test file and does not touch `e2e/scriptedJev.ts`. Open issues read: #518, #517, #516, #512, #490, #469, #452, #439, #415.

## Grill

**Not run.** The Skill tool refused `grill-with-docs` (`disable-model-invocation`: "reserved for explicit user invocation… do not replicate this skill's workflow by other means"), so no substitute was run and no questions are recorded here. The choices a builder would otherwise face are stated, with their citations, under The change. To grill this draft, the owner or orchestrator needs to run `/grill-with-docs` themselves.

## Owner decision needed

None on the fix. One gap in the brief: it requires a grill that this agent cannot invoke (see Grill).
