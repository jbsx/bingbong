---
test: e2e/pageMusic.e2e.test.ts:97
slug: pageMusic-97
status: confirmed
class: stale-test
cause_key: since #485 a line is asked on the Appliance Card first; a decisionScript entry in page-card labels is consumed there, reads malformed, and the page card's ask finds the script empty and reads failed
same_as: #518
---

# `pageMusic`'s "start it from the beginning" is scripted in page-card labels, which the Appliance Card consumes since #485

Part of #517. Same cause as #518, in a different file, and the same cause as finding `pageMusic-80`, the test just above this one in the same file. This adds one thing: this script label is the one the corpus already expects for this exact line on this card.

**Verdict: the test is out of date, the app is right.** With the card's own label scripted, the app restarts the page's video on one ask, with no search and no navigation. No file under `src/` changes.

**Scenario:** control (what is playing), yield 20, state `partly` (`docs/agents/yield.md`, spoken 2026-10-26). No change to the scenario or what the owner hears. It restores the e2e guard on restarting a song the Player never started.

## Proof for this test, at `c35c75b1`, under Xvfb

The failing line has not moved: 97, the same `waitFor` timeout of 20000 ms as #517 at `4ba056aa`. No real host was reached: every record below reads `model: scripted`.

| Run | Result |
|---|---|
| Unchanged, whole file | red 2 of 2 before the probe (2 failed, 2 passed; line 80 is the other red), 42 s |
| Unchanged, first test plus this one, by `-t` | red 1 of 1, line 97, the same timeout |
| Unchanged, `-t` this test alone | red 1 of 1, but at line 96, a different failure: see "Not in this issue" |
| Pattern widened with `not a command` (throwaway), the pair | red 1 of 1, in 2.4 s not 20 s: received `not a command: "start it from the beginning"` |
| Arm A: unchanged test, `BINGBONG_APPLIANCE_CARD=off` (throwaway, not the fix) | green, all 4 tests, 1 of 1 |
| Probe: the patch, whole file | this test green 3 of 3; line 80 stays red, 23 s |
| Probe: the patch, the pair by `-t` | green 1 of 1 |
| Probe reverted, whole file | red again, 1 of 1, 43 s |
| The patch on top of `pageMusic-80.patch`, whole file | all 5 tests green 2 of 2, 4.9 s |

Not run by me: the commit before #485. `pageMusic-80` ran it for this file: `7f1eab55` all 4 green, `a2297959` red on these same 2 tests.

**What was being waited on:** a CLI line matching `/^(restart \[\d+\]: |restart: |error:|No response|navigated:|playing:)/`. The app printed `not a command: "start it from the beginning"` (observed above, `src/main/cli/runCliHarness.ts:81`), which that pattern does not match.

**What the app recorded:**

```json
{"reading":"best_guess","verb":"none","target":null,"card":"page","jev":{"model":"scripted","reason":"failed"},
 "appliance":{"ask":"cli-2-mvv9dvuo-appliance","jev":{"model":"scripted","reason":"malformed"}},"mediaOp":null,"ended":"unavailable"}
```

The asks log has both asks:

- **Appliance Card:** `Playing: "Fixture Song - YouTube" playing 0:02/1:00 volume 100% loop off`. It offers `media-restart` and no `restart-1`.
- **Page card:** `[1] media "Fixture Song - YouTube" playing 0:02/1:00 volume 100% loop off`. It offers `restart-1`.

**The chain:**

1. `e2e/pageMusic.e2e.test.ts:56` scripts `readingOf('start it from the beginning', 'restart-1')`, one entry in a page-card label. The file was last changed on 2026-10-21 (`dcd233a6`, #374).
2. `a2297959` (#485, 2026-10-27) asks the Appliance Card first (`src/main/run/commandRunner.ts:1347`).
3. The stand-in removes the matching entry before reading it (`src/main/decision/createDecisionModel.ts:87`). `restart-1` is not on that card, so it reads `malformed` (line 92).
4. The line goes on to the page card (`commandRunner.ts:1358`), where the script has nothing left: `ran out of answers`, read as `failed` (`createDecisionModel.ts:88`).
5. The test's pattern does not include `not a command`, so it waits out 20 s and reports only `waitFor timed out`.

**Was this behaviour meant?** Yes. CONTEXT.md "Appliance Card" and ADR 0096: a pick fires there, and `page` or `none` sends the line on. The corpus says the same for this exact line: `fixtures/jev-cases/cli-3-mvhdfrhx-appliance.json`, `start it from the beginning`, expects `media-restart`. That case was read, not run (no paid ask here).

## The change

`e2e/pageMusic.e2e.test.ts` only. The exact diff from a clean tree is in `pageMusic-97.patch`. It conflicts with `pageMusic-80.patch` on line 56 alone, because both edit the script. Landing both means taking line 80's line and changing `restart-1` to `media-restart` in it.

1. **Script** (line 56): `readingOf('start it from the beginning', 'media-restart')`.
2. **Comment** (line 55), which the patch does not touch. It says the ops are ref 1's lines. Replace its second sentence with: `On the Appliance Card the video's ops are media-*, reaching it by kind; on the page card it is ref 1, its ops by ref (ADR 0096, ADR 0080); show is the Player's still.`
3. **Pattern and expectation** (line 97): add `not a command` to the pattern, so a miss fails at once with the app's own words. Expect `/^restart \[0\]: 0:\d\d → 0:00$/`. `[0]` is what an op by kind prints (`mediaOpHead(op.op, 0)`, `src/main/browser/createCdpBrowserController.ts:2630`).
4. **A new assertion after line 97:** the line's last decision record matches `{ reading: 'jev', card: 'appliance', verb: 'media', target: null, mediaOp: { op: 'restart' }, ended: 'terminal' }`.
5. **Keep as they are:** the `currentTime >= 2` wait before the line, `currentTime < 2` and `paused === false` after it, the unchanged `paneUrl`, and the title.

Do not set `BINGBONG_APPLIANCE_CARD=off`, and do not make the stand-in translate labels: either would prove a road the app does not ship by default.

## Acceptance criteria

- [ ] This test passes with the Appliance Card on, in a whole-file run, together with line 80's rewrite.
- [ ] It asserts the op on the element (`currentTime` back under 2 s, still playing) and the unchanged address, not only the CLI line.
- [ ] It asserts `card: 'appliance'`, `target: null` and `mediaOp.op: 'restart'` on the record.
- [ ] Its pattern includes `not a command`.
- [ ] The commit names the reason: the expectation went out of date with #485.
- [ ] No file under `src/` changes.

## Not in this issue

- **Line 80's test stays red under this patch.** It has its own finding, `pageMusic-80`, whose patch holds the page-road test.
- **Run alone, this test fails at line 96, not 97.** Nothing has navigated the pane, so there is no video and `currentTime >= 2` times out at 10 s. It needs the first test's `navigate`, like every test in this file. That is the file's existing shape, not this cause.
- **A green test does not say what a model picks.** The script assumes `media-restart`, so "rather than searching" is proven only as far as the op itself: the address stays and no search runs. The pick is the job of the corpus case named above.
- **`restart-1` on the page card is no longer fired by this file.** `pageMusic-80`'s page-road test still checks it is offered and fires `unloop-1` by ref, through the same `mediaOp` evaluate.

## Dependencies

No `Blocked by` edge. It shares a file with the `pageMusic-80` finding, and neither is filed yet, so landing them together is the simplest route. That is ordering, not a dependency. Issues read: the open list in `open.txt`, #518, and #517 with its failures table. None bears on this.

## Grill

`grill-with-docs` is not in this session's skill list. I loaded `grilling`; `domain-modeling` was not needed because nothing here touches the glossary. Answers are mine, from the sources cited.

- **App or test?** Test. CONTEXT.md "Appliance Card" and ADR 0096 say this is the road, and the probe shows the op lands: `restart [0]`, the video back under 2 s and playing, the address unchanged, one ask.
- **Does the test guard behaviour the app has lost?** No. The restart works on both roads: Arm A on the page card, the probe on the Appliance Card.
- **Why `media-restart` and not `page` then `restart-1`?** The corpus case for this exact line expects `media-restart`, from a real line. The script should follow what the card is meant to get.
- **Does `[0]` lose anything?** It no longer names the ref, because no ref is used on this road. `#movie_player video` is still checked by `facts()`, so the op is proven on the right element.
- **Should this test also check the ask's card?** No. `pageMusic-80`'s Appliance-road test checks `media-restart` is offered and that the card has no ref. Repeating it adds nothing.
- **Should line 96's wait go?** No. It makes the restart observable: the `→ 0:00` head needs a time to move from, and `mediaChangesOf` only reports a move.
- **Is there a tie to measure?** No. Test shape only, nothing the owner would feel.
- **Does it add a stage, wait, word or sentence?** No, so no Tier change and no UI principle applies.
- **Chart?** Not affected: test only.
- **Should `HANDOFF.md` go?** It is main's own tracked file from `bfd8b13e`, not a handoff from an agent on this test, so it stays. This branch had no handoff commit, and the diagnosis was done from the start.
