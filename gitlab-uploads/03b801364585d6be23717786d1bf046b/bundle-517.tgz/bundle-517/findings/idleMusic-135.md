---
test: e2e/idleMusic.e2e.test.ts:135
slug: idleMusic-135
status: confirmed
class: stale-test
cause_key: since #485 a line is asked on the Appliance Card first; a decisionScript entry in page-card labels is consumed there, reads malformed, and the page card's ask finds the script empty and reads failed
same_as: #518
---

# `idleMusic`'s "turn the music up" is scripted in page-card labels, which the Appliance Card consumes since #485

Part of #517. Same cause as #518, in a different file, and the same shape as finding `idleMusic-111`. This adds one thing: the test is the through-the-app guard on #459, so the rewrite must still catch #459's bug on the road the line now takes. A mutation run shows it does.

**Verdict: the test is out of date, the app is right.** With the card's own label scripted, the volume line under the duck reads the level put back, sets 70 %, and the release keeps it, on one ask. No file under `src/` changes.

**Scenario:** control (what is playing), yield 20, state `partly` (`docs/agents/yield.md`, spoken 2026-10-26). No change to the scenario or what the owner hears. It restores the e2e guard on a volume line under the duck, the break that row records (heard 55 → 13 → 7 → 11 → 50).

## Proof for this test, at `c35c75b1`, under Xvfb

The failing line has not moved: 135, the same `waitFor` timeout of 20000 ms as #517 at `4ba056aa`.

| Run | Result |
|---|---|
| Unchanged, whole file | red 3 of 3, line 135 each time |
| Unchanged, first test plus this one | red 1 of 1, same timeout, the records below |
| Unchanged, `-t` alone | red 1 of 1, a different failure: `evaluation failed: Uncaught` at line 128 in 6 ms, because nothing is playing |
| The change, whole file | this test green 2 of 2; lines 111 and 157 stay red |
| The change, first test plus this one | green 1 of 1 |
| The change plus the `idleMusic-111` patch, whole file (this change's label and line, without its new one-ask and record assertions) | 6 of 7 green, only line 157 red |
| The change, with `HEARD_VOLUME_FN` mutated to read `el.volume` (#459's bug, throwaway) | red 1 of 1, at once: `expected 'volume [0]: volume 9% → 3%' to be 'volume [0]: volume 60% → 70%'` |
| Unchanged test at `7f1eab55`, the parent of `a2297959` | green 1 of 1 |
| Unchanged test at `a2297959` (#485) | red 1 of 1, same timeout |

**What was being waited on:** a CLI line matching `/^(volume \[\d+\]: |error:|No response)/`. The app printed `not a command: "turn the music up"`, as in `idleMusic-111`, which the pattern does not match, so the test waited out its 20 s. I read that line from the sibling's finding and the record's `verb: none`, and did not capture it for this line.

**What the app recorded (unchanged):**

```json
{"transcript":"turn the music up","reading":"best_guess","verb":"none","jev":{"reason":"failed"},"card":"page",
 "appliance":{"ask":"…-appliance","jev":{"reason":"malformed"}},"ended":"unavailable"}
```

**With the change:** `reading: jev`, `verb: media`, `mediaOp: {op: volume, to: 70}`, `target: null`, `card: appliance`, `ended: terminal`. Its one ask's state reads `Playing: "Fixture Song - YouTube" playing 0:07/1:00 volume 60% loop off`, with the element ducked to 9 %.

**The chain:**

1. `e2e/idleMusic.e2e.test.ts:67` scripts `readingOf('turn the music up', 'volume-1', { amount: 'up-step' })`, one entry in a page-card label. It dates from `d2e7dd7d` (#459, 2026-10-26).
2. `a2297959` (#485, 2026-10-27) asks the Appliance Card first (`src/main/run/commandRunner.ts:1347`). The bisect above flips on this commit.
3. The stand-in removes the matching entry before reading it (`src/main/decision/createDecisionModel.ts:87`). The card offers `media-volume` and no `volume-1`, so it reads `malformed` (line 92).
4. A failed Appliance ask goes on to the page card (`commandRunner.ts:1359`), which does offer `volume-1`, but the script has nothing left for this line: `ran out of answers`, read as `failed` (line 88).

The app's #459 behaviour holds on the new road: the card's facts and the op share `MEDIA_FACTS_FN`, which reads `HEARD_VOLUME_FN` (`src/main/browser/pageMediaScript.ts:82,113`), and `applianceMediaOp` applies the same `APPLY_MEDIA_OP_FN` (`createCdpBrowserController.ts:2603-2632`).

## What this adds to #518's change

`e2e/idleMusic.e2e.test.ts` only. The exact diff is in `idleMusic-135.patch`.

1. **Script** (line 67): `readingOf('turn the music up', 'media-volume', { amount: 'up-step' })`. Update the comment on line 64 to name it.
2. **Line 135:** expect `volume [0]: volume 60% → 70%`, and add `not a command: ` to the pattern, so a miss fails at once with the app's words.
3. **Lines 136-138:** exactly one ask carries the line, and its state matches `/^Playing: .* volume 60% /m`.
4. **New assertion:** the line's decision record matches `{ verb: 'media', target: null, mediaOp: { op: 'volume', to: 70 }, card: 'appliance' }`.
5. **Lines 139-143 stay as they are:** the floor (`≤ 11`) and the release to 70 are the rest of #459's guard.

**Landing with `idleMusic-111`:** both patches change lines 64 and 67, so they conflict textually. Line 67 takes both sets of entries: `readingOf('play fixture song')`, `readingOf('loop the song', 'media-loop')`, `readingOf('stop looping this video', 'page')`, `readingOf('stop looping this video', 'unloop-1')`, `readingOf('turn the music up', 'media-volume', { amount: 'up-step' })`. The comment names all of them. The other hunks do not overlap.

Do not set `BINGBONG_APPLIANCE_CARD=off`, and do not make the stand-in translate labels.

## Acceptance criteria

- [ ] The test passes with the Appliance Card on, in a whole-file run.
- [ ] It asserts the 60 % read on the Appliance Card's `Playing:` line, one ask for the line, and `card: 'appliance'` on its record.
- [ ] It still asserts the element's floor under the duck and the release to 70 %.
- [ ] Reintroducing #459's bug (`HEARD_VOLUME_FN` reading `el.volume`) turns it red.
- [ ] The commit names the reason: the expectation went out of date with #485.
- [ ] No file under `src/` changes.

## Not in this issue

- **Line 157 stays red under this change.** It has its own finding.
- **`e2e/youtube.e2e.test.ts:116` has the same stale shape**, `volume-*`, with its expectation at line 249 on the volume line. It runs only under `BINGBONG_YOUTUBE_E2E=1` against real YouTube. I did not run it, so this rests on reading the code.
- **The page road under the duck is not driven through the app after this change.** `e2e/duckMark.chrome.test.ts:60` still guards the real collect and op there. A one-off arm scripting `page` then `volume-1` was also green, with the original expectations.
- **A green test says the road works, not that a real model picks `media-volume`.** That is a gate question.
- **The test still needs the first test's `play`.** Run alone it fails at line 128, as in `idleMusic-111`.

## Dependencies

No `Blocked by` edge. Open issues read: #415, #439, #452, #469, #490, #512, #516, #517, #518. #518 changes a different file, so neither waits on the other.

## Grill

`grill-with-docs` is not in this session's skill list, so I loaded `grilling`. I did not load `domain-modeling`, because nothing here touches the glossary. Answers are mine, from the sources cited.

- **App or test?** Test. CONTEXT.md "Appliance Card" and ADR 0096 say a line is read there first and a pick fires there. The change shows #459's behaviour intact on that road.
- **Does moving to the Appliance Card weaken #459's guard?** No. The mutation run goes red with `9% → 3%`, the shape of the bug `d2e7dd7d` recorded.
- **Why not also keep the page road here, as `idleMusic-111` does?** The hidden page's refs are that test's guard, not this one's. #459's page-road read and op are held by `duckMark.chrome.test.ts`. Which road this test scripts changes nothing the owner feels, so it is test shape, not a tie.
- **Why assert one ask?** It separates "fired on the Appliance Card" from "went on to the page card", which would give a different ref in the line but could still reach 70 %.
- **Which ref does the line print?** `[0]`: `applianceMediaOp` passes `mediaOpHead(op.op, 0)` (`createCdpBrowserController.ts:2630`), and the run shows it.
- **Should the test start from its own `play`?** No, for the reason in `idleMusic-111`: it is another scripted entry for state the file already shares, and it changes nothing the owner feels.
- **Does it add a stage, wait, word or sentence?** No, so no Tier change and no UI principle applies.
- **Chart?** Not affected: test only.
