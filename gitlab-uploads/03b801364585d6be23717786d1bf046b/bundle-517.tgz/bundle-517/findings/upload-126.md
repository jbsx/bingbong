---
test: e2e/upload.e2e.test.ts:126
slug: upload-126
status: confirmed
class: stale-test
cause_key: since #485 a line the Local Match cannot settle is asked on the Appliance Card first, so a decisionScript in page-card labels has its entry consumed by the Appliance Card ask, which reads malformed
same_as: upload-103
---

# e2e/upload still scripts the page card: the "attach my cv" proof for `upload-103`

Part of #517. Same cause and same change as `upload-103`, whose body stands. This file holds the proof for line 126 and the one thing this test adds. The test is out of date and the app is right: with the script corrected, the Shelf ask reads `none`, nothing is set, no dialog opens, and the app says no file fits.

**Scenario:** as `upload-103`: no upload row on the Yield list, nearest `goal` (yield 4, `partly`, `pnpm goal:gate` 2026-10-27). No change to any scenario or its state. It restores the e2e guard on the road where no file fits (#424, ADR 0092), which has guarded nothing since #485.

## Reproduction

All at `c35c75b1` under Xvfb on the scripted stand-in, except the two base runs. Nothing reached a real host: the suite sets `BINGBONG_DECISION_SCRIPT`, and every ask in the fixed runs records `"model":"scripted"`. The failure is the same as #517's at `4ba056aa`: line 126, `waitFor` timeout of 20000 ms. Line 126 waits in `cli()` for `/^(clicked \[1\]|error:)/`, and the app never prints either.

The kept-log runs carried a throwaway log copy in `afterAll`, on existing lines so that line numbers did not move. It is not in the patch.

| Run | Alone (`-t 'attach my cv'`) | Whole file |
|---|---|---|
| Unchanged | red 1 of 1 | red 1 of 1 (4 failed, 1 passed) |
| `upload-117`'s patch + this test's asserts | green 2 of 2 | green 2 of 2 (5 passed) |
| Same, with only the cv line's `page` entry removed | red 1 of 1 | red 1 of 1 (**this test alone red**, 4 passed) |
| Saved patch, log copy removed | not run | green 1 of 1 (5 passed) |

No flake: every run went the way its script predicts, and alone and whole file never differed. `pnpm typecheck` and eslint on the patched file report no errors.

**Start of the failure, unchanged test built at each commit, alone:**

| Commit | Result |
|---|---|
| `7f1eab55` (parent of #485) | passed |
| `a2297959` (#485) | failed, 20 s timeout |

## What the app did on this line

The chain is `upload-103`'s, read here from this line's own records. These are from the whole-file run; the alone run differs only in its ask id (`cli-2-…`).

1. The Appliance Card ask takes the line's entry 1, `click-1`, and reads `malformed`, since that card has no such option.
2. The page card ask takes entry 2, the one meant for the Shelf: `action: none`.
   `{"reading":"jev","verb":"none","card":"page","ask":"cli-4-mvvby5l0","appliance":{"ask":"cli-4-mvvby5l0-appliance","jev":{"reason":"malformed"}}}`
3. A hop-0 `none` asks again (ADR 0082). That `-where` ask finds the script empty and the line ends `unavailable`.
   `{"reading":"best_guess","verb":"none","ask":"cli-4-mvvby5l0-where","jev":{"reason":"failed"},"ended":"unavailable"}`
4. Nothing was clicked. The asks for the line are `appliance`, `command`, `where`, with no `shelf`, and no ask carries `fate`.

With the fix the record reads:
`{"reading":"jev","verb":"click","card":"page","target":1,"ended":"terminal","appliance":{"chose":"page"},"upload":{"file":null,"reason":"none","shelf":3,"ask":"cli-4-mvvbzg5c-shelf"}}`, with asks `appliance`, `command`, `shelf`.

**Why the test and not the app:** ADR 0096 rules the Appliance Card first, and `fixtures/jev-cases/shelf-attach-my-cv-card-appliance.json` expects this very line to read `page|none` there. The road past the card is unchanged, as the green runs show.

## What this test adds to `upload-103`'s change

The script change is already in `upload-103`, including `readingOf(LINES.cv, 'page')`; without that entry this test stays red, as the third row shows. Patch: `findings/upload-126.patch`. It applies alone on `c35c75b1` and contains all of `upload-117.patch` plus the edits below, so a builder applies this one instead of the other two.

The old assert `{ file: null, shelf: 3 }` also holds for an empty read that is not `none`: `src/main/run/commandRunner.ts:2310` returns `file: null` with `reason: 'unread'` when the Shelf ask goes unanswered, and that says a different sentence (`:2191`). So in `e2e/upload.e2e.test.ts`:

- `DecisionLine.upload` gains `reason?: string`.
- In the `attach my cv` test, take `const since = harness.cliMark()` before the `cli` call.
- Line 127: expect `{ ended: 'terminal', card: 'page', appliance: { chose: 'page' }, upload: { file: null, reason: 'none', shelf: 3 } }`.
- After it: `await harness.waitForCliOutput(/^said: "No file on the shelf fits that upload\."$/, { since })`.

No stage, wait, word or sentence is added, so no Tier, UI or chart change applies. The input-to-output flow does not change.

## Acceptance criteria to add

- [ ] The cv test passes with the Appliance Card on, whole file and alone.
- [ ] It asserts the Appliance Card's `page` pick, the page card's click, `file: null` with `reason: 'none'` on all 3 Shelf files, the said line, no new `change` on the page, and no OS dialog.

## Not in this issue

- Whether a real model reads `none` here is the gate's question, not this test's: the `none` is scripted. `fixtures/jev-cases/shelf-attach-my-cv-shelf.json` already expects `none` for this line, and I did not run it (no paid or gate runs in this job).

## Dependencies

No blocking edges. I read the open issues on 2026-10-30 (#518, #517, #516, #512, #490, #469, #452, #439, #415): none blocks this.

## Grill

The named `grill-with-docs` skill is not available in this session. I loaded `mattpocock-skills:grilling` and answered its questions myself, as the brief says.

- **Is the shared cause proven here, or inherited?** Proven here: this line's records, the base pair built and run alone, and a flip that turns only this test red.
- **Does a `none` from the Shelf need any app change?** No. With the script corrected, the road from the chooser to the said line is green with no `src/` change.
- **Is `reason: 'none'` too tight an assert?** No. It is the only thing telling this road from `unread`, whose sentence differs. `commandRunner.test.ts` covers `empty` and `unread` with the same field.
- **Should the said line use the constant `SPOKEN_FAILURES.noShelfFile`?** No. The sibling invoice assert spells out its sentence, and `withNextLine` adds nothing to this line (`src/core/command/tryLine.ts:47`), so the sentence is exact.
- **Does the test need `cliMark`?** Yes. The said line must come from this line, not from output an earlier line in the file left in the harness's buffer.
- **`page` or `none` on the Appliance Card?** `page`, settled in `upload-103`. The corpus accepts both, and the test does not depend on the difference.
- **Does a tie need measuring?** No. Nothing here changes what the owner hears or how fast.
- **Is `HANDOFF.md` a handoff for this test?** No. The resume brief pointed to it, but the file at the worktree root is the orchestrator's from main (`bfd8b13e`), and no handoff commit sits on this branch. It stays, per the standing rule never to remove it from main.
