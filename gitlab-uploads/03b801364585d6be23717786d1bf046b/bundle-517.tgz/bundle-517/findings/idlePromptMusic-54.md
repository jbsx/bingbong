---
test: e2e/idlePromptMusic.e2e.test.ts:54
slug: idlePromptMusic-54
status: confirmed
class: stale-test
cause_key: audio-only music is on by default since 78aed4f0; the harness's fake yt-dlp has no stream unless the suite scripts one, so the lookup is refused, the play falls back to the watch page, shown, and the dashboard wakes
same_as: none
---

# e2e/idlePromptMusic has no stream for the audio road: since 78aed4f0 its `play` falls back to the watch page, which wakes the dashboard and takes the Prompt away

Part of #517.

The test is out of date; the app is right. Since audio-only music became the default (78aed4f0), a `play` looks up its stream first. The harness's fake yt-dlp refuses any lookup a suite has not scripted, so this suite's play always takes the fallback: the watch page, shown. CONTEXT.md says exactly that ("a road that fails, opens the watch page, shown"). The screen goes, the Prompt goes with it, and the test waits 15 s for an Answer in a Prompt that no longer exists. Test change only.

**Scenario:** play (play something by words), yield 20, state `partly`, evidence in `docs/agents/yield.md`, unchanged by this issue. What the owner hears does not change. The change puts back the e2e guard on a `play` typed over the Idle Screen on the road the app ships, which has guarded nothing since 2026-10-28. It also keeps the guard on the page road's focus hand-back.

## Root cause

1. `78aed4f0` (2026-10-28) set `audioOnlyMusic` on by default (`src/core/settings/settings.ts`). This suite's profile has no `settings.json`, so its play takes the road (`roadFor`, `src/main/music/player.ts:913`).
2. The harness points the road at the fake for every suite (`BINGBONG_AUDIO_ROAD`, `e2e/harness.ts:208`). The fake refuses when `BINGBONG_FAKE_YTDLP_STREAM` is unset (`e2e/bin/fake-yt-dlp.mjs`, `!stream`). This suite does not set it (`e2e/idlePromptMusic.e2e.test.ts:36`). Observed fault: `music.player.resolve`, "the lookup was refused".
3. A refused lookup opens the watch page instead (`open`, `src/main/music/player.ts:932`), and with the road taken the outcome is marked `shown: true` (`player.ts:1165`). Observed `media-start`: `road:"page", fallback:true`, Answer "Playing “Fixture Song” on its watch page."
4. The runner publishes `shown` (`src/main/run/commandRunner.ts:2206`), and `shown` wakes the Idle Screen (`src/core/idle/idleWake.ts:11`). Observed: `shown`, then `display`, then `done`, about 1.9 s after Enter. After that the dashboard has no `.idle-screen` and no `.idle-prompt`; its text is `Ready`, `Fixture Song · Fixture Band` and the watch URL.
5. Line 54 waits for `.idle-prompt-answer`, which went with the Prompt, so it runs out at 15 s. The `play` itself worked: the song was playing (`element.paused:false`, `time:1.7`).

`930140b3` (#502, 2026-10-29) fixed the same cause in `idleMusic` and `idleShot` by saving the road off. Its message names the cause. This file was missed.

Steps 3 and 4 are the app doing what was ruled, so they are not the bug: CONTEXT.md, **Audio road** (lines 1591–1597), and `IdlePrompt.tsx`'s own header ("One that opens a page wakes the dashboard and this goes with the screen").

## Evidence, all at `c35c75b1`, under Xvfb, scripted stand-in only

The failure matches #517's at `4ba056aa`: same line, same 15000 ms timeout. Not rerun at `4ba056aa`. The test is unchanged by the two commits between.

| Run | Result |
|---|---|
| Unchanged, whole file | red 3 of 3 (2 before the probes, 1 after reverting them) |
| Alone (`-t`) | red 2 of 2 (1 unchanged, 1 with only a dump added) |
| `78aed4f0^` (`626175c2`), built and run | 2 of 2 tests pass |
| `78aed4f0`, built and run | both tests red, same timeouts |
| Arm R: only `BINGBONG_FAKE_YTDLP_STREAM` added | whole file green 3 of 3, alone green 1 of 1 |
| Arm P: only `{ audioOnlyMusic: false }` saved | whole file green 3 of 3, alone green 1 of 1 |
| The change below, both roads, whole file | 4 of 4 tests pass, 3 of 3 runs (not run with `-t`; the builder owes that) |

Both arms also turn this file's second test (line 71) green. It waits on the state the first test leaves.

**Arms.** Green cannot separate R from P, so the measure was named before the mutation: which arm goes red when the behaviour the test's comment claims to guard is broken. Mutation: `onPaneFocus` (`src/main/index.ts:539`) returns at once.

| Road | With the mutation, 2 of 2 runs |
|---|---|
| audio | both tests stay green; no page load takes focus there |
| page | the first test goes red at `document.hasFocus()`, `expected false to be true`; the other test stays green |

So each road guards something the other cannot: audio is what ships by default, and page is the only one that reaches the focus hand-back. Neither arm replaces the other, and the change keeps both.

## The change

`e2e/idlePromptMusic.e2e.test.ts` only. The full diff is the probe patch `idlePromptMusic-54.patch`; it applies cleanly at `c35c75b1`.

- Run the suite with `describe.each` over two roads, each with its own launch:
  - `audio`: profile `{}`, so the shipped default decides. Env `BINGBONG_FAKE_YTDLP_STREAM: fixture.url('/youtube-fixture/song.wav')` and `BINGBONG_FAKE_YTDLP_MS: '1000'`.
  - `page`: profile `{ audioOnlyMusic: false }`, an explicit off a kiosk may hold (78aed4f0's caveat).
- In the first test, after the Answer, read the first `media-start` from `logs/perf-*` and expect `{ road, fallback: false }`.
- Keep every existing assertion: the Answer holds the title, the dashboard has focus, the Prompt closes, the Idle Screen is up, the card names the song.
- Change the file's header comment and the focus comment to say which road does what.

Do not change `e2e/harness.ts`, the fake, or `src/`.

## Acceptance criteria

- [ ] Both tests pass on both roads, whole file and with `-t`.
- [ ] The `audio` road's profile does not set `audioOnlyMusic`, so a change of default turns the test red instead of passing silently.
- [ ] The first test asserts `road` and `fallback: false` from the `media-start` record on each road, not only the Answer.
- [ ] With `onPaneFocus` disabled, the `page` road's first test goes red.
- [ ] The commit names the reason: the expectation went out of date with 78aed4f0, and 930140b3 missed this file.
- [ ] No file under `src/` changes.

## Not in this issue

- **The Prompt's fallback Answer.** When the road really fails, a `play` typed in the Prompt loses the Prompt within about 2 s, and its words are shown on the dashboard instead. That follows the ruling and nothing here changes it. No test guards it from the Prompt; `e2e/audioRoad` guards the refused lookup from the dashboard.
- **Other suites.** Any suite that types `play` with no stream and no saved off takes the same fallback. Each is being diagnosed under #517. A harness-wide default stream is not proposed here: every suite that scripts the road today does it per file (`audioRoad`, `idleMusic`, `idleShot`).
- **The fake's silent refusal.** A suite that forgets the stream gets a refused lookup and a fault in the log, not a clear test failure. The `road`/`fallback` assertion covers this file only.
- **`src/core/music/audioRoad.ts:2`** still says the setting is "off by default", which 78aed4f0 made false. A comment only.

## Dependencies

Blocks nothing and is blocked by nothing. Read the open issues as of 2026-10-30: #518, #517, #516, #512, #490, #469, #452, #439, #415. #516 changes the real lookup, not the fake, so the two do not touch.

## Grill

Answered from the sources named; nothing went to the owner.

- **Is the app wrong to wake the dashboard on a fallback?** No. CONTEXT.md, **Audio road**: "a road that fails, opens the watch page, shown". `player.ts:1165` and `idleWake.ts:11` do that.
- **Is the test guarding behaviour the app has lost?** No. A `play` over the screen still keeps the screen up and closes the Prompt on the shipped road, as Arm R shows. Only the fixture lacked a stream.
- **Is saving the road off, as `idleMusic` does, enough?** No. Alone it proves a road that is not the default (#518's rule: a test proves the road the app ships by default). Arm R is the primary arm for that reason.
- **Then why keep a page-road test at all?** It is a tie the mutation measured: only the page road reaches `onPaneFocus`, which still ships, and an explicit off stays off on any kiosk that saved it. It is a real setting's road, not a switch set off to get green, because the default road is tested beside it.
- **Fix in the harness or the file?** The file. The code beside it decides: all three suites that handle the road do so per file.
- **Is the `BINGBONG_FAKE_YTDLP_MS` value a fork?** No owner would feel it. 1000 ms is chosen so the Prompt really shows its `…` through a wait; it was run at that value, and no scenario on the Yield list changes.
- **Which log proves the road?** `media-start` in `perf-*`, which already carries `road` and `fallback` (`player.ts:1053-1058`). `idleMusic` already reads logs this way.
- **Does this add a stage, a wait, a word or a sentence?** No. It is a test change, so no Tier, UI principle or chart change applies.
- **Does a real line belong in the Failed Lines ledger?** No. No line misbehaved; the fixture did.

## Asks for the orchestrator

None. No paid model and no kiosk read were needed. `idlePromptMusic-71` is expected to share this cause (it flipped in every arm here) and needs its own proof.

For whoever reads this job: this session was started as a resume, but no handoff for this test existed. The `HANDOFF.md` at the worktree root is main's tracked 2026-10-29 music note, so it was left in place, not deleted. The diagnosis was done from scratch.
