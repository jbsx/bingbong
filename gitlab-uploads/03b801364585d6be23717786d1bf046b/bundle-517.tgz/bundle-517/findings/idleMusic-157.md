---
test: e2e/idleMusic.e2e.test.ts:157
slug: idleMusic-157
status: confirmed
class: app-bug
cause_key: a tap on an Idle Screen control fires a line that brings the Turn Card down over that control, and the card takes the next tap
same_as: none
---

# A tap on an Idle Screen control brings the Turn Card down over the control, and the card eats the next tap

Part of #517.

**Verdict: the app is wrong, not the test.** Tap Pause on the Now Playing card and the song pauses, but a 1240×680 Turn Card comes up for that `pause` line and covers the controls for 15 s. The next tap only closes the card, so Play takes two taps. CONTEXT.md says the card is up "from the wake word or a typed Idle Prompt line", and a control's tap is neither. The test has guarded this since #365, and it went red the day the card landed (`a60a28fa`, #474). #474 updated `peekCard` and `stageFeedback` and did not touch `idleMusic`.

**Scenario:** control (what is playing), yield 20, state `partly` (`docs/agents/yield.md`, spoken 2026-10-26). That row is spoken lines, so its state does not change. This fixes the same scenario by hand: one tap, one effect. It also restores the e2e guard on the card's controls.

## Root cause

1. `src/renderer/src/NowPlayingCard.tsx:38-41`: each control submits its verb as a Command through `assistant.submit`, on the pointer going down.
2. `src/core/idle/turnCard.ts:201-203` (`adopt`): the fold opens for any line's first event, whatever started it. It cannot tell a tap from a typed line, so it disagrees with CONTEXT.md's Turn Card entry.
3. `src/renderer/src/App.tsx:200`: `turnUp = turn.state.phase === 'open'`, so the Idle Screen draws the card.
4. `src/renderer/src/styles.css:2797` and `:2789`: the card is centred at 1240×680 over a scrim, and the Now Playing controls are in the middle Column beneath it. The hit test at the Play button's centre returned `DIV.turn-history`.
5. `src/renderer/src/TurnCard.tsx:200-204`: the card's pointer-down closes it and stops the event, as designed ("a tap closes it"). So the Play tap never reaches the button: no `play` line is recorded, and the video stays paused. Line 157 waits for `paused === false` until its 10 s run out.

The first wrong thing is link 2: the card has no notion of a tap's line.

## Evidence, at `c35c75b1`, under Xvfb

**What was being waited on:** `facts().paused` to go false after the Play tap. What the app did, from the probe in whole-file order, base source:

```
before-play {"top":"DIV.turn-history","turn":{"state":"done","text":"…Thinking“pause” Read as pause Acting Done Paused."}}
after-play  {"top":"path.","turn":null}          ← the tap closed the card
after-play-facts {"paused":true,"currentTime":47.08}
```

The decision log has the tap's `pause` (`turn-mvv9ycno-1`, `local_match`) and no `play` from the tap. The next `play` in the log is `cli-5`, from the following test.

| Run | Result |
|---|---|
| Unchanged test, base source, whole file | red 1 of 1 at line 157, as in #517; the probe copy in the same order red 1 of 1 at the same step |
| Same steps, the file without the two tests before it (probe) | red 1 of 1 **earlier, at the Pause step**: the `play` line's card is still up and takes the Pause tap (hit test `SPAN.turn-step-text`) |
| Unchanged test at `4f081a9e`, the parent of `a60a28fa` | green, 5 of 5 tests |
| Unchanged test at `a60a28fa` (#474) | red 1 of 1, only this test, at its wait after the Pause tap (line 145 there) |
| **Flip:** the app change, unchanged test, whole file | this test green 2 of 2; lines 111 and 135 stay red |
| **Revert:** the changed test, base source | red 1 of 1, in 287 ms: `expected true to be false` at the new card assertion, line 160 |
| The change (app and test), whole file | this test green 1 of 1; lines 111 and 135 stay red |
| The change plus the `idleMusic-111` and `idleMusic-135` test patches, whole file | **7 of 7 green, 2 of 2** |
| The final diff (the ear rule added last), with the same two sibling test patches, plus `turnCard` and `peekCard` | **13 of 13 green, 1 of 1**. The other rows with the change predate the ear rule. |
| `-t` alone, with the change | red 1 of 1 in 7 ms at line 156: `element not found`, because no song is held. Not run alone on base source. |
| `turnCard`, `peekCard` with the change | green |
| `stageFeedback`, `stateShots` with the change | green, 16 of 16 |
| `idleTimer` with the change | red at line 63, as in #517. See "Not in this issue". |

The earlier reds matter. Lines 111 and 135 each wait out 20 s, which drains the card before this test starts, so at 4ba056aa only Play fails. Once those two are fixed the card from the line before is up too. The test must close it first, which is why the change below does.

**Arms.** The fork is what to change. The measure, named before building: the #365 test in whole-file order, plus `turnCard` and `peekCard`.

| Arm | What | Result |
|---|---|---|
| T, test only | close the card before each of the 7 taps; no card assertions | this test green 1 of 1, and a person still needs two taps per control |
| A, app | a tap's line brings no card unless it fails | this test green with its taps unchanged, and neighbours green |

Both pass the test, so the measure does not separate them. CONTEXT.md does (Grill, Q1), and Arm T also leaves the bug in place while making its guard green. Arm A wins; Arm T left the tree. The exact diff of Arm A is at `/home/jbsx/.claude/jobs/7b9f65fd/tmp/findings/idleMusic-157.patch`.

**Receipt measured on Arm A, not previously asserted:** from the dispatched tap to `.idle-music-card--paused` or `--playing`, 6 taps: 18–28 ms, under Xvfb on the dev machine. Not measured on the kiosk.

**Not run:** `pnpm test` whole, and the full e2e suite. `turnCard.test.ts` (26 of 26) and typecheck are clean on the final diff, and so is eslint on the fold, its test and `tapCommand.ts`. `NowPlayingCard.test.ts` and eslint on the other changed files were clean before the ear rule, which does not touch them.

## The change

Exact diff in `idleMusic-157.patch`.

- **`src/renderer/src/tapCommand.ts` (new):** `tapCommand(line)` tells its listeners a tap is pending, submits the line, and tells them it settled. `onCommandTap(listener)` subscribes.
- **`src/renderer/src/NowPlayingCard.tsx`:** `tap()`'s `submit` calls `tapCommand(verb)`.
- **`src/renderer/src/IdleScreen.tsx`:** the ringing Timer's `dismiss` calls `tapCommand('timer off')`. Same kind: it fires a Command and leaves the screen up. The Last Page and News rows are left alone, because those Commands wake the screen and the card goes with it.
- **`src/renderer/src/useTurnCard.ts`:** subscribes `fold.onControlTap`.
- **`src/core/idle/turnCard.ts`:**
  - State gains `tapped: boolean`. The fold gains `onControlTap(pending)`.
  - `adopt` gives the next hop-0 turn to the pending tap and sets `tapped` for that turn.
  - `onVoice` clears `tapped` when the ear opens, so a wake over a tap's slow line (a `previous` loading a song) still gets its card.
  - New `turnCardShows(state)`: `phase === 'open' && (!tapped || end === 'failed')`.
- **`src/renderer/src/App.tsx`:** `turnUp = turnCardShows(turn.state)`. The fold still folds the line, so a failure can show and the Peek Card's strip is unchanged.
- **`src/core/idle/turnCard.test.ts`:** three cases: a tap's line shows no card, a failed one does and the next line does; the ear opening over a running tap brings it up; a tap that started no line leaves the next line its card.
- **`e2e/idleMusic.e2e.test.ts`, this test only:** close a card left by the last typed line first; then assert `.turn-card` is absent after the Pause, Previous and last picture taps. The taps themselves do not change.

**Landing with others.**
- `idleMusic-111` and `idleMusic-135` change other tests in the same file, with no overlap with this one.
- `idle-221` changes the same line in `App.tsx`. Together: `const turnUp = turnCardShows(turn.state) && (turn.state.end === null || turn.state.openedAt !== cardGone.current)`.

**The rules:**
- Jev: not touched. Mechanism only, by kind (a control that leaves the screen up), no site or line.
- Reliability: no new stage on the Command's path. Tier Instant. Felt Reaction before: the second tap has no effect. After: 18–28 ms to the card's state on the dev machine.
- UI principles:
  - 1 (Receipt): met, by the control's own state change, inside 100 ms as measured.
  - 2 (Narrated wait): met for a slow `previous`, by the Wait Card (#507) and `STARTING`; the Turn Card no longer doubles it.
  - 3 (undo as fast as done): met, the next tap now lands.
  - 7 (one thing first): met, no scrim for a tap.
  - **Bend:** a tap whose Answer is its only effect ("Nothing queued.", "Nothing before this.") is said and goes to the Feed, with nothing on the screen. With the sound muted it says nothing at all. See Grill, Q3.
- **Chart: must be updated.** The latest version (`2026-10-30-f3712c4e-voice-back`) says "Idle Screen: the Turn Card" for a line's feedback, with no tap exception.

**Wording proposed for the owner, CONTEXT.md's Turn Card entry (not applied):**

> A tap on an Idle Screen control that leaves the screen up (a Now Playing control, the ringing Timer) brings no card: the control shows what it did, and the next tap lands on it. If its line fails, the card comes up on Failed.

## Acceptance criteria

- [ ] The test passes in a whole-file run, on the shipped road, with no switch set off.
- [ ] After a Pause tap, `.turn-card` is absent and the next tap on Play plays the video: one tap, one effect.
- [ ] Reverting the app change turns the test red at the card assertion.
- [ ] A tap's line that fails still ends the Turn Card on Failed (`turnCardShows`, unit test).
- [ ] A wake over a tap's running line brings the card up, and a typed or spoken line still does (unit tests).
- [ ] `turnCard`, `peekCard`, `stageFeedback` and `stateShots` stay green.
- [ ] The chart is updated in the same change, with the affected view inspected.
- [ ] The commit says the guard went red with #474.

## Not in this issue

- **`e2e/idleTimer.e2e.test.ts:63` stays red under this change.** There the line before is `timer 6s`, so its card may be what takes the tap. Not diagnosed here. So the ringing Timer's move to `tapCommand` has no green e2e behind it yet, only the shared road's.
- **A person who speaks a line and taps a control within 15 s still needs two taps.** That is "a tap closes it" as ruled. Unchanged.
- **The test needs the first test's `play`.** Run alone it fails on no song, like its siblings.
- **The Feed is what `answered` reads,** not anything on the Idle Screen. It proves the line ran, not that the person saw it.
- **`.turn-card` absence is asserted after the Pause, Previous and last picture taps,** not after every tap.

## Dependencies

No `Blocked by` edge. Open issues read: #415, #439, #452, #469, #490, #512, #516, #517, #518. None touches the Turn Card's opening. This also clears the way for `idleMusic-111` and `idleMusic-135`, but neither waits on it.

## Grill

`grill-with-docs` is not in this session's skill list, so I loaded `grilling`. I did not load `domain-modeling`, because the only glossary change is the proposal above. Answers are mine, from the sources cited.

- **Q1. App or test? The test could close the card first (Arm T).** App. CONTEXT.md: "up from the wake word or a typed Idle Prompt line". Now Playing's entry: each control submits its verb "and unlike them leaves the Idle Screen up". And the rule that a test guarding lost behaviour is an app bug. #474's body and commit name spoken and typed lines only, and neither mentions taps.
- **Q2. But "a tap closes it" is the owner's ruling. Does the fix cross it?** No. A tap on a card that is up still closes it. The fix stops a card coming up for a tap's own line.
- **Q3. Should an Answer-only tap ("Nothing queued.") show the card?** **A guess.** No measure reaches it: only the owner's day would tell. Taken: no card, the arm cheapest to reverse, one condition in `turnCardShows`. Reason: the person is at the screen with a hand out, and a 15 s scrim for "Nothing queued." costs the next tap. What would settle it: the owner tapping Skip with nothing queued on the kiosk and saying whether they knew what happened.
- **Q4. Must a failed tap show the card?** Yes. CONTEXT.md: one that fails there "ends the Turn Card on Failed". It covers the control for 15 s, which is acceptable for a failure.
- **Q5. Why not pass the tap through the card to what is under it?** It would fire a control the person cannot see, against principle 3.
- **Q6. Why not move the card or the controls?** The owner picked the centred card (#474, variant E); and Now Playing's place is in CONTEXT.md.
- **Q7. Why mark the tap in the renderer rather than carry a source through IPC and events?** Code shape, no one feels the difference, and it touches fewer files: no change to the preload, the runner or `PipelineEvent`. The race (a spoken line's first event between the tap and its own, in the few ms it takes) is closed by the submit settling and by the ear clearing `tapped`.
- **Q8. Does the Peek Card change?** No. It reads the fold's state, and `peekCard` stays green.
- **Q9. Should this test start from its own `play`?** No, as `idleMusic-111` found: it changes nothing the owner feels.
- **Q10. Does Jev or the gate come into it?** No. Every tap line is a `local_match`, and no paid ask was made.
