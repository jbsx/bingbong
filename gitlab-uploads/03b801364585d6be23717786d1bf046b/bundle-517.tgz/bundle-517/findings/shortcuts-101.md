---
test: e2e/shortcuts.e2e.test.ts:101
slug: shortcuts-101
status: confirmed
class: stale-test
cause_key: the test's focus('dashboard') clicks a fixed point (640,15) that has been the Toolbar's drag region since #436, so X focus stays on the pane and the keys never reach the dashboard
same_as: none
---

# e2e/shortcuts' `focus('dashboard')` clicks the Toolbar's drag region since #436, so the keys it sends land on the pane and the dashboard's chords go unguarded

Part of #517.

The red in `e2e/shortcuts.e2e.test.ts` is an out-of-date test, not an app bug. Ctrl+X in the address field works once the field has real focus. The test's fixed click point stopped landing on the field when #436 made the Toolbar taller. Test change only; no change to the app.

The same helper also feeds two tests that are green but hollow. `Ctrl+R on the dashboard…` and `Alt+Left and Alt+Right…` have pressed their keys on the pane since 2026-10-26, so nothing guards those chords on the dashboard.

**Scenario:** none on the Yield list. That list ranks spoken use, and this is a keyboard chord in a typed field. No scenario changes state. The change restores the e2e guard on the shortcuts from the dashboard surface (a4d9a452: "each chord lands on the browsing pane from every surface") and on the clipboard chords with no menu.

## Root cause

1. `e2e/shortcuts.e2e.test.ts:16` hard-codes the dashboard's focus point as window pixel (640, 15), described as "the toolbar band".
2. At a4d9a452, when the test was written, that point was on the field: Toolbar 76 px tall, `.url-input` at x 452–938, y 14–62. `elementFromPoint(640,15)` read `url-input`, and the click gave the dashboard focus.
3. `9db2d2ba` (#436, 2026-10-26) took the Toolbar to 104 px for the capsule's 65 px type and narrowed the field (`--tb-h`, `src/renderer/src/styles.css:103`). The field moved down to y 28–76, and (640,15) became bare `.toolbar`. At c35c75b1 the field is at x 643–963, y 27.5–75.5.
4. The bare Toolbar is `-webkit-app-region: drag` (`src/renderer/src/styles.css:294`), as ADR 0012 and CONTEXT's **Toolbar** entry rule. A real click on a drag region does not move focus to the dashboard. Measured below: `document.hasFocus()` stays false under `drag` and turns true under `no-drag`. So this part of the app is as ruled.
5. The test's next step, `harness.clickDashboardElement('.url-input')` (`e2e/shortcuts.e2e.test.ts:95`), is a CDP click. It focuses the field inside the dashboard's document (`activeElement` = `url-input`), but real X keys still go to the surface holding X focus, which is the pane.
6. `press('ctrl+a')` and `press('ctrl+x')` therefore run on the pane's `<body>`. The value stays `kept words`, and the assertion at line 101 fails.

First wrong thing: link 1, the test's hard-coded point. The app is not at fault: the #436 commit message records the Toolbar growth as intended, and the field cuts and pastes under a real click.

## Evidence

All at `c35c75b1` under Xvfb unless a sha is named. The failure is the same as #517's at `4ba056aa`: same line, same message.

**Reproduction**
- Unmodified whole file: red 2 of 2, the clipboard test only, the other 7 green.
- Alone (`-t 'clipboard chords'`): red 1 of 1.
- Whole file and alone agree, so it does not depend on earlier tests. It is not timing either: the point misses every time.

**Where the keys went** (throwaway probe, capture listeners in both surfaces)
- After the X click at (640,15): dashboard `hasFocus` false, pane true.
- After the CDP click: dashboard `activeElement` = `url-input`, and its log has no `keydown`.
- After Ctrl+A, Ctrl+X and Ctrl+V, the pane's log has `keydown:a`, `keydown:x`, `beforecut`, `cut`, `keydown:v`, `paste`, all on the pane. The dashboard's log has none of them.
- `xclip -o -selection clipboard`: `target STRING not available`, so nothing was cut.

**Bisect** (the clipboard test alone, with a build at each sha)

| sha | Toolbar height | `elementFromPoint(640,15)` | test |
|---|---|---|---|
| a4d9a452 (test written) | 76 | `url-input` | pass |
| 9db2d2ba^ | 76 | `url-input` | pass |
| 9db2d2ba (#436) | 104 | `toolbar` | fail |
| 234c3434 | 104 | `toolbar` | fail |
| ad1382e7 (#453) | 104 | `toolbar` | fail |

**The drag region is the reason, not just "not the field"**: a real click on (640,15), with the pane clicked first each time.
- `-webkit-app-region: drag` (shipped): dashboard `hasFocus` false.
- `no-drag`, set at runtime: dashboard `hasFocus` true.

**Probe flip** (`shortcuts-101.patch`, test file only)
- With the patch: whole file 8 of 8 green on 3 of 3 runs; clipboard test alone green, 1 of 1.
- Reverted: red again, same assertion, 7 of 8 green.

**The two hollow tests** (mutation: `win.webContents` taken out of the `attachAppShortcuts` list at `src/main/index.ts:816`, so the dashboard no longer hears the shortcuts)
- Old `focus()`: `Ctrl+R on the dashboard` and `Alt+Left…` stay green. Only the clipboard test is red, for its own reason.
- New `focus()`: exactly those two go red and the other 6 pass, including the clipboard test.

Not run: `pnpm typecheck`, `pnpm lint` or `pnpm test` on the patch. It touches one e2e file.

## The change

`e2e/shortcuts.e2e.test.ts` only. `shortcuts-101.patch` is the whole change.

- Move `focus()` inside the `describe` and make it async, since it needs `harness`.
- For `'dashboard'`, read the point from the field: the centre of `document.querySelector('.url-input').getBoundingClientRect()`, rounded. Dashboard CSS pixels equal window pixels here; the zoom test asserts its `devicePixelRatio` is 1. `'pane'` stays (640, 450).
- After the click, `waitFor` (5 s) `document.hasFocus()` in the dashboard to equal `surface === 'dashboard'`. A point that misses again then fails in `focus()` by name, instead of passing silently or failing later on a value.
- Say in its comment why: the Toolbar's band is a drag region and takes no focus; a CDP click never moves X focus.
- Every call site becomes `await focus(...)`. The clipboard test drops `harness.clickDashboardElement('.url-input')`, because the real click already focuses the field.

Keep the rest of the clipboard test as it is, including seeding the value with `.value = 'kept words'`, and leave Toolbar height, the drag region and `src/` alone. Do not add a menu or a Ctrl+X handler: the chord already works.

## Acceptance criteria

- [ ] All 8 tests in `e2e/shortcuts.e2e.test.ts` pass, whole file and clipboard test alone, on the shipped app with no switch set.
- [ ] `focus('dashboard')` takes its point from the field's live rect, with no fixed coordinate, and fails by itself if the dashboard did not get real focus.
- [ ] The clipboard test sends its keys after a real X click only, with no CDP click in it.
- [ ] Checked once and recorded in the commit: with `win.webContents` taken out of the list at `src/main/index.ts:816`, `Ctrl+R on the dashboard` and `Alt+Left…` go red. That mutation is then reverted.
- [ ] The commit names the reason: the expectation went out of date with #436 (9db2d2ba).
- [ ] No file under `src/` changes.

## Not in this issue

- Other files' coordinates: `e2e/stateShots.e2e.test.ts` and `e2e/audioRoad.e2e.test.ts` also use xdotool. A grep finds no `640, 15` in them, but their click points were not checked.
- The other tests in #517, none looked at here.

## Dependencies

None. Open issues read: #518, #517, #516, #512, #490, #469, #452, #439, #415. None blocks this or touches this file.

## Grill

The grill-with-docs skill is not installed in this session, so this ran on `mattpocock-skills:grilling`, answered from the docs and measurement. CONTEXT.md, the ADRs and AGENTS.md need no new wording.

- **Is the app wrong to let a Toolbar click leave focus on the pane?** No. ADR 0012 (lines 62–65) and CONTEXT's **Toolbar** make the band the window's drag region, and the measure above shows a drag region takes no focus. No ruling asks for more, and the owner drives by voice.
- **Does the test guard behaviour the app has lost?** No. With a real click the field cuts and pastes with no menu: 3 of 3 whole-file runs and 1 of 1 alone.
- **Why the field and not another dashboard control?** The clipboard test needs that field focused anyway, the back and forward buttons act when clicked, and the rest of the band is drag. One point serves every dashboard test.
- **Why read the rect and not a new fixed pixel?** A fixed pixel is what broke when the layout moved. #453 moved the field again the same day (x 763 at ad1382e7, x 643 now).
- **Why assert `hasFocus`?** The old helper went wrong silently and left two tests hollow for four days. `hasFocus` in the dashboard told the two cases apart in every probe. It is not exclusive on the pane side (the pane still reads true after a CDP click), so the check reads the dashboard only.
- **Does focusing the field disturb `Ctrl+R` or `Alt+Left` on the dashboard?** No: 8 of 8 on 3 of 3 runs. Those chords are taken in main's `before-input-event` before the field sees them.
- **Could `.value =` be undone by a re-render, since it bypasses React's draft?** In theory. It did not happen in 4 of 4 patched runs, so the line stays and the change stays small. If this test ever flakes on that value, `harness.typeIntoDashboard` is the replacement. This is not a tie: the owner would feel neither arm.
- **Yield, Tier, UI, chart?** No scenario changes. No stage is added to a Command's path, so no Tier applies. No wait, state, word or sentence is added. The input-to-output flow is unchanged, so the chart needs no update.
- **Any fork that needs measuring?** None the owner would feel. No paid model was used, and the test reaches no decision host.
