---
test: e2e/idleMusic.e2e.test.ts:111
slug: idleMusic-111
status: confirmed
class: stale-test
cause_key: since #485 a line is asked on the Appliance Card first; a decisionScript entry in page-card labels is consumed there, reads malformed, and the page card's ask finds the script empty and reads failed
same_as: #518
---

# `idleMusic`'s "loop the song" is scripted in page-card labels, which the Appliance Card consumes since #485

Part of #517. Same cause as #518, in a different file. This adds one thing #518 does not have: the test is also the guard on a hidden page's refs, and that guard must survive the rewrite.

**Verdict: the test is out of date, the app is right.** With the card's own label scripted, the app loops the video on one ask with the Idle Screen up. No file under `src/` changes.

**Scenario:** control (what is playing), yield 20, state `partly` (`docs/agents/yield.md`, spoken 2026-10-26). No change to the scenario or what the owner hears. It restores the e2e guard on looping over the Idle Screen, and on the hidden page's refs.

## Proof for this test, at `c35c75b1`, under Xvfb

The failing line has not moved: 111, the same `waitFor` timeout of 20000 ms as #517 at `4ba056aa`.

| Run | Result |
|---|---|
| Unchanged, whole file | red 3 of 3 (the 2 sibling reds at lines 135 and 157 each time) |
| Unchanged, `-t` alone | red 2 of 2 |
| Unchanged, with the first test's `play` | red 1 of 1, the records below |
| Arm A: unchanged test, `BINGBONG_APPLIANCE_CARD=off` (throwaway, not the fix) | green 1 of 1, `loop [1]: loop on` |
| Arm B: the change below, whole file | both new tests green 2 of 2; lines 135 and 157 stay red, the last test stays green |
| Arm B: first test plus the two new tests | green 1 of 1 |
| Arm B reverted, whole file and alone | red again, 1 of 1 each |

**What was being waited on:** a CLI line matching `/^(loop \[\d+\]: |loop: |error:|No response)/`. The app printed `not a command: "loop the song"`, which that pattern does not match, so the test waited out its 20 s.

**What the app recorded:**

```json
{"transcript":"loop the song","reading":"best_guess","verb":"none","jev":{"reason":"failed"},"card":"page",
 "appliance":{"ask":"…-appliance","jev":{"reason":"malformed"}},"ended":"unavailable"}
```

The asks log has both asks. The Appliance Card offered `media-loop` and no `loop-1`. The page card did offer `loop-1`, with `[1] media "Fixture Song - YouTube" playing 0:04/1:00 volume 100% loop off` on its state, so the hidden page's refs are still being read.

**The chain:**

1. `e2e/idleMusic.e2e.test.ts:67` scripts `readingOf('loop the song', 'loop-1')`, one entry in a page-card label. The line dates from `1ba1e84d` (#372, 2026-10-21).
2. `a2297959` (#485, 2026-10-27) asks the Appliance Card first (`src/main/run/commandRunner.ts:1347`). That commit changed no e2e file.
3. The stand-in removes the matching entry before reading it (`src/main/decision/createDecisionModel.ts:87`). `loop-1` is not on the card, so it reads `malformed` (line 92).
4. A failed Appliance ask goes on to the page card (`commandRunner.ts:1359`), where the script has nothing left for this line: `ran out of answers`, read as `failed` (line 88).

Not run: the commit before `a2297959`. The start date rests on the chain and on Arm A.

## The change

`e2e/idleMusic.e2e.test.ts` only. The exact diff is in `idleMusic-111.patch`.

1. **Script** (line 67), keeping the `play` and volume entries as they are: `readingOf('loop the song', 'media-loop')`, `readingOf('stop looping this video', 'page')`, `readingOf('stop looping this video', 'unloop-1')`. Update the comment on line 64 to match.
2. **Split the test in two**, because it guards two roads:
   - **Appliance road.** `loop the song` prints `loop [0]: loop on`. There is exactly one ask for the line, its state has the `Playing:` line and no `Refs (number`. Its options include `media-loop`, `media-restart`, `media-pause`, `play`, `queue` and `page`, and not `loop-1`. The record has `verb: 'media'`, `target: null`, `mediaOp.op: 'loop'`, `card: 'appliance'`.
   - **Page road, the guard this test must keep (ADR 0079: a hidden page is collected at its real size; ADR 0080).** `stop looping this video` prints `unloop [1]: loop off`. The page card's state has refs, including `[1] media … loop on`. Its options include `unloop-1`, `restart-1`, `pause-1`, `play` and `queue`, and not `loop`. The record has `target: 1`, `card: 'page'`, `appliance.chose: 'page'`.
3. **Add `not a command: ` to both patterns**, so a miss fails at once with the app's words, not as a 20 s timeout. Measured: with no video on the card, the new test failed with `expected 'not a command: "loop the song"' to be 'loop [0]: loop on'`.

Do not set `BINGBONG_APPLIANCE_CARD=off`, and do not make the stand-in translate labels.

## Acceptance criteria

- [ ] Both new tests pass with the Appliance Card on, in a whole-file run.
- [ ] Each asserts `video.loop` on the element and that the Idle Screen is up, not only the CLI line.
- [ ] The page-road test asserts the hidden page's refs and the media ref's state on the ask.
- [ ] The commit names the reason: the expectation went out of date with #485.
- [ ] No file under `src/` changes.

## Not in this issue

- **Lines 135 and 157 stay red under this change.** Line 135 scripts `volume-1`, a page-card label of the same kind, but I did not diagnose it; both have their own findings.
- **The page-road script assumes Jev picks `page`.** A green test says the road works, not that a real model takes it. Measuring that would be a gate question.
- **The test still needs the first test's `play`.** Run alone it fails, because nothing is playing. The other tests in this file share that state.

## Dependencies

No `Blocked by` edge. #518 changes a different file, so neither waits on the other. Open issues read: #517 and #518 only, not the whole tracker, so a builder should check for others before filing.

## Grill

I loaded `grilling`; `grill-with-docs` is not in this session's skill list, and I did not load `domain-modeling` because nothing here touches the glossary. Answers are mine, from the sources cited.

- **App or test?** Test. CONTEXT.md "Appliance Card" says a pick fires there, and Arm B shows the behaviour intact.
- **Is anything lost if the test just moves to the Appliance Card?** Yes: the hidden-page refs check, since that card has no refs. Hence the second test. ADR 0079 still requires that behaviour.
- **Why `unloop-1` for the page road?** It needs a line that really reaches the page card, and `loop on` on the ref proves the state was read from the hidden page. It also puts the loop back off, so later tests start as they did. Which op to use is test shape, not a tie the owner would feel.
- **Does it add a stage, wait, word or sentence?** No, so no Tier change and no UI principle applies.
- **Chart?** Not affected: test only.
- **Should this test start from its own `play`?** No. That is another scripted entry for state the file already shares, and it changes nothing the owner feels. It is the one lead in #517 this leaves untaken.
