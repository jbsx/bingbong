---
test: e2e/idleTimer.e2e.test.ts:63
slug: idleTimer-63
status: confirmed
class: app-bug
cause_key: a Turn Card's scrim covers the whole Idle Screen, so while any line's card is up a tap on the ringing Timer lands on the scrim and the alarm keeps ringing
same_as: none
---

# While a Turn Card is up, its scrim takes the tap on a ringing Timer and the alarm keeps ringing

Part of #517.

The app is wrong, not the test. CONTEXT.md says of the Timer that "a tap on it while it rings turns it off", and the Timer itself says "tap to stop". But any line's Turn Card stays up until 15 s after that line ends, and its scrim covers the whole screen. If the Timer rings in that window, or a line is answered while it rings, the tap lands on the scrim. Nothing happens and the alarm carries on, however many times it is tapped. The test has been red since the Turn Card landed (`a60a28fa`, #474, 2026-10-26). Waiting the card out in the test would turn it green and leave the bug.

**Scenario:** `timer` (kitchen timer: set, how long left, stop), ~2 a day, yield 0, state `works` (`docs/agents/yield.md`, rerun 2026-10-23 on main 413191a9). The state and yield do not change: that row's evidence is spoken, and "stop" still silences the alarm by voice. This restores the e2e guard on the tap, which has guarded nothing since #474, and fixes a dead control while an alarm sounds. It is not a high-yield fix. The window is only the 15 s or so after a line, and only for someone tapping.

## Root cause

1. `e2e/idleTimer.e2e.test.ts:42` submits `timer 6s` with the Idle Screen up. The fold (`src/core/idle/turnCard.ts`) opens a Turn Card for the line, as CONTEXT.md's Turn Card entry says it should, and holds it 15 s after the line ends (`reschedule`, `PEEK_CARD_LINGER_MS`). The line ends at once, so the card is still up when the Timer rings at 6 s.
2. `src/renderer/src/TurnCard.tsx:194` draws `.turn-scrim`, and `src/renderer/src/styles.css:2789` makes it `inset: 0; z-index: 4`.
3. `src/renderer/src/styles.css:2659`, `.idle-timer--ringing`, has no stacking of its own, so the ringing Timer lies under the scrim. **This is the first thing that is wrong.** The scrim was written to dim the rest of the screen so the card comes first (#474, ui.md 7). Nothing in #474 or CONTEXT.md asks it to disable a live control, and #474 never mentions a ringing Timer under it.
4. The test's `clickDashboardElement('.idle-timer--ringing')` at line 61 lands on the scrim. `dismiss` at `src/renderer/src/IdleScreen.tsx:141`, which submits `timer off`, never runs, so the status stays `ringing` and the wait at line 63 times out.

This is a different fault from `idle-221`. There, a card that should have gone comes back. Here the card is rightly up, so `idle-221`'s change does not reach this: it only acts on the screen's rising edge over a line already over, and here the screen was up first (read from that patch; not run alone).

## Evidence

All at `c35c75b1` unless named, under Xvfb, on the scripted stand-in. No paid model or real host was asked for: the harness unsets the routing keys.

**Reproduction**
- Whole file: red 3 of 3 at line 63. Alone with `-t`: red 3 of 3. Same failure as #517's, not order-dependent and not timing. The file's other test passed every run.

**What the app did** (probe, one run at the harness's 1280×800), reading `elementFromPoint` at the ring's centre and a capture-phase `pointerdown` log:

| moment | status | under the ring's centre | taps landed on |
|---|---|---|---|
| ringing, card up (`Done Timer set for 6 seconds`) | ringing | `DIV.turn-scrim` | |
| after tap 1 | ringing | `DIV.turn-scrim` | `turn-scrim` |
| after tap 2 | ringing | `DIV.turn-scrim` | `turn-scrim` ×2 |
| card expired | ringing | `P.idle-timer-left` | |
| next tap | **off** | | `P.idle-timer-left` |

At the kiosk's 1920×1080 (emulated) the ring is at y 34–180 and the card starts at y 200, so only the scrim is over it, not the card. At 1280×800 the ring ends at y 160 and the card starts at y 173.

**Bisect** (whole file, one run each):

| commit | result |
|---|---|
| `a60a28fa~1` | 2 of 2 pass |
| `a60a28fa` (#474) | this test red at line 63 |

**The fork is what to change.** The measure, named before building: does one tap on the ring turn it off, in two cases (case 1, the setting line's finished card is up; case 2, a line read as none comes up over a ring already sounding), at 1280×800 and 1920×1080, with `idleTimer` ×3 and `turnCard`, `peekCard`, `idleByVoice` green. Case 2 was added because a single card state cannot tell the arms apart. All arms were built here.

| arm | what it does | tap, both cases, both sizes | `idleTimer` | siblings | "No response" card in case 2 | Time's up in the kiosk shot |
|---|---|---|---|---|---|---|
| Base | nothing | red, 4 of 4 | red | 7 pass | kept | (96,57,37), dimmed |
| **raise** | ring at `z-index: 6`, above scrim and card | **green, 4 of 4** | 3 of 3 | 7 pass | **kept** | (168,89,49), not dimmed |
| hide | no card while ringing once its line is over | green, 4 of 4 | 3 of 3 | 7 pass | **gone** (`face: null`) | not dimmed |
| through | scrim `pointer-events: none` | green, 4 of 4 | 3 of 3 | 7 pass | kept | (96,57,37), dimmed |
| test only (not built) | wait 15 s before tapping | | | | | alarm still ignores the tap |

Colour figures are the most saturated pixel in the words, one sample per shot during a pulsing animation, so they are indicative only. The base and `through` values match; `raise` being brighter is also visible in the shots, which I inspected.

Winner: **raise**.
- `hide` breaks a written rule: "Every line is answered: a reading of `none` is shown and said" (AGENTS.md, Reliability). The card that shows it would go at once.
- `raise` and `through` tie on the tap measure, and this split is not from that measure. `through` leaves the live words dimmed under the scrim, and it also makes every tile under a card tappable, for every line and whether or not a Timer rings. That second effect is read from the code; I did not run `idle` or `stateShots` on `through`. `raise` touches only a ringing Timer, and both are one line to reverse.

**The patch's flip**, at `/home/jbsx/.claude/jobs/7b9f65fd/tmp/findings/idleTimer-63.patch` (the CSS and two test guards):

| run | result |
|---|---|
| patch, whole file | 3 of 3 runs, 3 of 3 tests each |
| patch, this test alone | green |
| CSS reverted, tests kept, whole file | red at line 65, the same wait. The new test is also red there, at line 78, but that is a cascade: the ringing Timer left by the first failure |
| CSS reverted, new test alone | red at line 82, the wait for `off`. This is its real proof |
| patch, `idle`, `stateShots`, `turnCard`, `peekCard`, `idleByVoice` | 32 of 33; the one red is `idle:221`, red on base too |
| patch, `idleShot` with `BINGBONG_IDLE_SHOT=1` | 10 pass, 1 red (`idleShot:254`), the same red as base |
| this patch with `idle-221.patch`, `idleTimer` and `idle` | 16 of 16 |

## The change

`src/renderer/src/styles.css`, at `.idle-timer--ringing` (line 2659):

```css
/* A ringing Timer stands above a Turn Card's scrim (z-index 4) and beside its card (5): it is live, says "tap to stop", and a line's card reports only one line. */
.idle-timer--ringing {
  position: relative;
  z-index: 6;
  cursor: pointer;
}
```

`e2e/idleTimer.e2e.test.ts`:
- In the first test, just before the tap, assert the card is up, so the test keeps proving the road past the scrim:
  ```ts
  // The line that set a short Timer is still on its Turn Card as it rings: the tap below has that card's scrim to get past.
  expect(await harness.dashboardEval<boolean>(`!!document.querySelector('.turn-card')`)).toBe(true)
  ```
- Add a test between the two existing ones, `a line answered over the ringing Timer keeps its card, and a tap on the Timer still turns it off`: submit `timer 2s`, wait for `.idle-timer--ringing`, submit `xyzzy plugh`, wait for `.turn-card` with `data-state="dropped"`, assert the status is `ringing`, tap the ring, and wait for `off`. It must not go last, because the existing last test wakes the screen. The patch has the exact code.

Do not wait the card out or dismiss it in the test, do not hide the card while ringing (`hide` above), and do not make a tap on the card or scrim silence the alarm: CONTEXT.md says a tap on the card closes it.

Checks by AGENTS.md:
- **Jev:** no ask, card or list changes. By kind: every ringing Timer under every card.
- **Reliability:** no stage added to a Command's path, so no Felt Reaction changes.
- **UI (`docs/agents/ui.md`):** no wait, state, word or sentence added. Meets 6 ("a dead thing looks dead": an offered "tap to stop" now works) and 8 (the live thing's accent is no longer dimmed). Bends 7 slightly: while it rings, the card is no longer the only bright thing. That is deliberate, since the alarm is what is live.
- **Chart:** no update. The input-to-output path is unchanged; a search of the latest version (`2026-10-30-f2c21d13-no-read-verb`) for ring and tap found no step for this tap. The builder confirms this in the completion summary.

Wording proposed for the owner, for CONTEXT.md's Turn Card entry (not applied, per the rule on drafting first):

> A ringing Timer stands above the scrim, so a tap on it still turns it off with a card up.

## Acceptance criteria

- [ ] `e2e/idleTimer.e2e.test.ts` passes whole, three runs in a row, on the default road with no switch set.
- [ ] The first test asserts `.turn-card` is present before its tap, and the tap is on `.idle-timer--ringing`.
- [ ] The new test asserts the `dropped` card is up and the status is `ringing` before its tap, then `off` after it.
- [ ] With the CSS change removed, the first test goes red, and the new test goes red when run alone with `-t`.
- [ ] A tap on the card still closes it with the screen left up (`peekCard`, `turnCard` green).
- [ ] `idleByVoice` and `stateShots` stay green, and `idle` and `idleShot` have no red beyond those already on base (`idle:221`, `idleShot:254`, unless their own fixes have landed).

## Not in this issue

- `idleShot:254` (the Calendar's month entries) is red on base and with this patch. It is not among #517's failures because the file needs `BINGBONG_IDLE_SHOT=1`.
- `turnCard` passed every run here (5 of 5, base and arms), though #517 records `turnCard:162` red. That is for its own diagnosis.
- A tile under a card that is rightly up still gives its tap to the scrim. `idle-221` records this too, and it stays as is.

## Dependencies

None. Open issues read: #518, #517, #516, #512, #490, #469, #452, #439, #415, and the finding `idle-221`. No genuine blocking edge. This patch and `idle-221`'s apply and pass together, in either landing order.

## Grill

`grill-with-docs` is not among this session's skills, so I used `grilling`, answering each question from the docs, the code and the arms.

- **Is the test out of date, since the card came later?** No. CONTEXT.md's Timer entry still says a tap turns it off, and the ring still says "tap to stop". #474 does not rule otherwise. The test guards behaviour the app lost.
- **Does "a tap closes it" (Turn Card) win over the Timer's tap?** No conflict: that sentence is about a tap on the card. The ring is not under the card at either size measured.
- **Is the card wrong to be up as it rings?** No. CONTEXT.md holds it 15 s after the line and names the Timer among lines shown over the screen. A short Timer inside that hold is ordinary.
- **Should the card go when the ring starts?** Measured: `hide` loses the `none` card, against AGENTS.md Reliability. A variant that closes the card only on the ring's first moment would miss case 2. I did not build it, as it cannot pass the measure.
- **Should any tap silence the alarm?** No. It would override the card's own tap, which CONTEXT.md settles, and a tile's.
- **Does z-index 6 reach past the columns?** Measured yes: `.idle-col` and `.idle-clock-row` make no stacking context that stops it, and `onRing: true` at both sizes. The Night Dim veil (z-index 10) stays above and passes taps through. The Idle Prompt (z-index 20) stays above too.
- **Could it collide with anything at z-index 5 or 6?** No. `.idle-wait-place` (z-index 6) is pinned to the foot of the screen (`styles.css:1080`, `bottom: 12px`, 176 px tall) and takes no taps, and the ring is at the top. Read from the CSS; not run with a Wait Card up.
- **Is the 1920×1080 result real?** Emulated through `emulateDashboardSize`, as `idleShot` does. The Xvfb screen size alone does not resize the window (1280×800 both ways), so that first attempt measured nothing and is not counted.
- **Does the Yield rule object to yield 0?** No. #517 asks for every red to be diagnosed, and this restores a guard.
- **Does the ledger need a line?** No. It records lines that did not do what was meant, and this is a tap, not a line (`docs/agents/bugs.md`).

## Owner decision needed

None.
