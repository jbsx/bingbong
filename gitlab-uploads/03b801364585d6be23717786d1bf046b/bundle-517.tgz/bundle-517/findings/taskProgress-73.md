---
test: e2e/taskProgress.e2e.test.ts:73
slug: taskProgress-73
status: confirmed
class: stale-test
cause_key: the scripted hub Task has two gaps, each enough alone: the stand-in never answers a hop's `passage` Choice (#401), so the hop reads malformed; and since #485 a line is asked on the Appliance Card first, so a decisionScript entry in page-card labels is consumed there and reads malformed
same_as: taskProgress-47
---

# AC3 reads the Feed of the Task AC2 walks, so it is red for taskProgress-47's cause

Part of #517. The shared issue is `taskProgress-47`, and this file adds only what AC3 brings to it.

The test is out of date and the app is right. AC3 has no walk of its own: it reads the Feed entry left by the Task AC2 submits. `taskProgress-47`'s two-gap fix turns it green, with no change to `e2e/taskProgress.e2e.test.ts` and none under `src/`.

## Proof for this test

All runs were at `c35c75b1`, under Xvfb, on the scripted stand-in. Nothing reached a real host or real Jev. The failure is the same as #517's at `4ba056aa`, and the line is still 73. Logs are in `/home/jbsx/.claude/jobs/7b9f65fd/tmp/tp73-run/`.

| Script | Run | AC3 | Feed at AC3 |
|---|---|---|---|
| Unchanged | whole file | **red 2 of 2** | `[[],["back"]]` |
| Unchanged | AC3 alone | red 1 of 1 | `[]` |
| `page` entry only | whole file | red 1 of 1 | `[[],["click [1] \"Regional hub Aurora\""]]` |
| `passage` only | whole file | red 1 of 1 | `[[],["back"]]` |
| Both (`taskProgress-73.patch`) | whole file | **green 3 of 3** | four action lines, all of AC3's patterns match |
| Both | AC2 and AC3 only (`-t 'AC2\|AC3: the Feed'`) | green 1 of 1 | four action lines |
| Both | AC3 alone | **red 1 of 1** | `[]` |
| Both reverted | whole file | red 1 of 1 | `[[],["back"]]` |

- **The flip:** red turns green with both fixes and back to red when they are reverted. Each single fix stays red, so AC3 needs both gaps closed, as AC2 does.
- **Patch:** `taskProgress-73.patch` is byte-identical to `taskProgress-47.patch`. It has no change of its own.
- **Commits that introduced it:** I did not bisect again. `taskProgress-47`'s history table has the whole file green at `44e21b45`, Gap A first bad at `ad848423` (#401) and Gap B first bad at `a2297959` (#485). The Feed states in my single-fix arms match the ones it recorded.

## How this test differs

1. **AC3 is red alone on any script, by design.** Line 69 reads the Feed once, and only AC2 submits the Task, so the Feed is `[]` and the assertion fails even with the fix. That is not a separate bug, but it does mean a builder who checks with `-t 'AC3'` will see a false red.
2. **`["back"]` in `[[],["back"]]` is a script slip, not a choice.** It is the one action of the Task that ended early, taken from the second script entry landing on the page card (`taskProgress-47`, Gap B). No model chose it. The `[]` beside it is an entry with no action lines.
3. **The one-shot read did not flake.** AC3 reads the overlay once with no wait, which is the same kind of read that made `stageFeedback-128` flaky. Here it follows AC2's full bar and its last `idle()`, and it was green 4 of 4. Those four runs do not measure the margin. They do show that this test does not need the wait `stageFeedback` needs.

## What this adds to the shared issue

**The change:** nothing beyond `taskProgress-47`'s. `e2e/taskProgress.e2e.test.ts` stays as it is, and AC3 does not get its own walk. A second walk would add about 10 s and prove nothing AC2 has not set up.

**Acceptance criteria, add:**

- [ ] AC3 is checked in a whole-file run or with `-t 'AC2|AC3: the Feed'`, never by `-t` on AC3 alone, which is red on any script because it reads AC2's Task.
- [ ] AC3 still asserts all four lines and their readings: `Regional hub Aurora … closer`, `back … unsure`, `Regional hub Borealis … no closer` and `audit for hub Borealis … closer`, with the two `not.toMatch(/no closer$/)` lines kept.

**Scenario:** the same as `taskProgress-47`: question, yield 10, state `partly` (rerun 2026-10-24 on main 20f843b5). The owner hears no change and the row's state does not move. It restores the guard on the Feed's closer, unsure and no closer words (#375). No Tier, UI principle or chart change, since this is test code only.

## Not in this issue

- AC3 depending on AC2's state is how this file is written, and the file's tests are ordered on purpose (the third test also relies on "the last Task's" bar). It is noted above so nobody chases it, not proposed for change.

## Dependencies

None. I read #518 and `taskProgress-47` in full, and #517's table. For the other open issues I relied on `taskProgress-47`'s reading and did not re-read them.

## Grill

`grill-with-docs` is not in this session's skill list, so I loaded `grilling` and answered each question myself. I did not load `domain-modeling`, since no term or ADR changes.

- **Is AC3's red its own bug or a cascade?** A cascade of AC2's Task, not of AC2's assertion. The Feed itself is short because the walk ended early. Each single-fix arm shows the Feed changing with the script, while AC3's code never changes.
- **Should AC3 walk its own Task so it can run alone?** No. The code beside it decides this: the file is written as one ordered walk, and the third test relies on it too. The owner cannot feel the difference.
- **Should AC3 poll instead of reading once?** No. It was green 4 of 4, and it reads after AC2's final `idle()`. Add a wait only if a run shows the race.
- **Does the Feed show the app is wrong anywhere?** No. With the Task walked, all four lines carry the words #375 meant, and the patterns last changed in `d5fe4053`, the review fixes for #375.
- **Does the fix change what ships?** No. No file under `src/` changes and no switch is set off, so the test proves the default road with the Appliance Card on.
