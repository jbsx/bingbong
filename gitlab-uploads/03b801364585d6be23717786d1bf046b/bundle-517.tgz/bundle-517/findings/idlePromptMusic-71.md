---
test: e2e/idlePromptMusic.e2e.test.ts:71
slug: idlePromptMusic-71
status: confirmed
class: stale-test
cause_key: audio-only music is on by default since 78aed4f0; the harness's fake yt-dlp has no stream unless the suite scripts one, so the lookup is refused, the play falls back to the watch page, shown, and the dashboard wakes
same_as: idlePromptMusic-54
---

# The song the second `idlePromptMusic` test relies on falls back to the watch page, so no Idle Screen is left to type on

Part of #517. Same cause and same change as `idlePromptMusic-54`. This adds the proof for line 71, and one correction to that draft: its acceptance criterion "both tests pass with `-t`" cannot stand for this test, and this test must assert the song it claims.

**Verdict: the test is out of date, the app is right.** With a stream scripted, a typed key opens the Prompt again over the playing song and Escape closes it, with the screen up. No file under `src/` changes.

**Scenario:** play (yield 20, state `partly`, `docs/agents/yield.md`), unchanged by this issue. What the owner hears does not change. It restores the e2e guard on typing over the Idle Screen while a song plays, on the road the app ships.

## Proof for this test, at `c35c75b1`, under Xvfb, scripted stand-in only

The failing line has not moved: 71, the same `waitFor` timeout of 5000 ms as #517 at `4ba056aa`.

| Run | Result |
|---|---|
| Unchanged, whole file | red 4 of 4 (2 baseline, 1 with a dump added, 1 after reverting the flip) |
| Unchanged, `-t` alone | **green 2 of 2**: no first test, so the Idle Screen is still up, but no song is playing either |
| Flip: unchanged file plus only `BINGBONG_FAKE_YTDLP_STREAM` | both tests green, 1 of 1 |
| Flip reverted | both tests red again, 1 of 1 |
| The change below, whole file, both roads | 4 of 4 tests pass, 3 of 3 runs |
| The change below, `-t` alone, both roads | red at once on both roads, as intended: `expected { title: '', toggle: '' } to deeply equal { title: 'Fixture Song', … }` |

**What was being waited on:** `.idle-prompt-input` holding `x`.

**What the app did** (dumped at the start of the test and 1.5 s after the key, in a whole-file run):

- Before the key: `.idle-screen` absent, no Prompt, dashboard text `Ready / Fixture Song · Fixture Band / the watch URL`. The pane is on the watch page, `video.paused:false`.
- After the key: still no Idle Screen and no Prompt. A keydown listener in the pane recorded `x`, so the key went to the page, as it should with the dashboard awake.
- `media-start` for the first test's `play`: `road:"page", fallback:true`.

**The chain:** links 1 to 4 of `idlePromptMusic-54` wake the dashboard. Then `attachIdleTyping` hears a key only while `idleShown.up` holds (`src/main/index.ts:535`, `src/main/idleTyping.ts:14`). The screen is down, so main passes `x` on to the page, the Prompt never opens and line 71 runs out. The first commit was not re-run for this test: `idlePromptMusic-54` ran `78aed4f0^` (both tests pass) and `78aed4f0` (both red).

## What this test adds to the change

The base is the change in `idlePromptMusic-54`. The full diff, including that change, is `idlePromptMusic-71.patch`; it applies at `c35c75b1`. Add to `e2e/idlePromptMusic.e2e.test.ts`:

- A `songCard()` helper reading `.idle-music-title` text and the `aria-label` of `.idle-music-button--main`.
- In this test, before the key and again after Escape: `expect(await songCard()).toEqual({ title: YOUTUBE_FIXTURE_SONG.title, toggle: 'Pause' })`.

**Why the assertion is needed.** The title says "with the song playing" and "again", and today nothing checks either.

- The lone run goes green with no song, as the table shows.
- I measured "again" with a throwaway mutation: a Prompt once closed goes on telling main it holds focus (`IdlePrompt.tsx` cleanup emptied, `App.tsx:187` `prompting = promptFocused`).

| With the mutation | Result |
|---|---|
| Whole file, with the change | this test red on both roads at the `x` wait; the first test green on both |
| `-t` alone, `idlePromptMusic-54`'s patch only, no assertion | green on both roads |

So only a run after the first test reaches this guard. A lone green proves neither claim in the title, so a lone run should say so. No mutation was built that the card assertion alone catches; what it does is turn a false green into a red that names the missing song.

## Acceptance criteria

- [ ] Replaces `idlePromptMusic-54`'s "Both tests pass on both roads, whole file and with `-t`" with: both tests pass on both roads in a whole-file run; the first also passes with `-t`; this one, with `-t`, fails at once on the song card and not on a timeout.
- [ ] This test asserts the card's title and `Pause` before the key and after Escape, on both roads.
- [ ] With a closed Prompt still reporting focus, this test goes red on both roads and the first test stays green.
- [ ] No file under `src/` changes.

## Not in this issue

- **Escape does not prove focus.** The test sends Escape to the dashboard's CDP session directly, so it reaches the page whoever holds focus. The field keeping focus rests on the first test's `document.hasFocus()`.
- **A key leaking to the page as well as opening the Prompt** is not asserted. The fixture's watch page has no key handlers, so a leak would pause nothing.

## Dependencies

No `Blocked by` edge. Land together with `idlePromptMusic-54` as one issue: same file, same launch. Open issues read: #518, #517, #516, #512, #490, #469, #452, #439, #415.

## Grill

I loaded `grilling` and answered as the owner's stand-in, as the brief asks. `grill-with-docs` and its `domain-modeling` step were not used: the first is not in this session's skill list, and nothing here touches the glossary.

- **Is a key going to the page with the dashboard awake a bug?** No. `idleKey.ts` and `idleTyping.ts` scope typing to the Idle Screen, and the fallback waking the screen is ruled (CONTEXT.md, **Audio road**, "a road that fails, opens the watch page, shown").
- **Should this test start from its own `play`, so `-t` can pass with a song?** No. That is a second scripted entry and it would lose "again", which the mutation shows needs an earlier Prompt. `idleMusic` shares state between tests the same way, and `idleMusic-111` kept that.
- **Why is the lone run red and not skipped?** Code shape, no owner would feel it. Red is the smallest change and says what is missing.
- **Is `Pause` a word the card really shows on both roads?** Measured: 3 of 3 runs on both.
- **Which road proves this?** Both, for the reason `idlePromptMusic-54` measured. Its `BINGBONG_FAKE_YTDLP_MS: '1000'` stands; this test went green both with it (the change) and without it (the flip).
- **Stage, wait, word, sentence or chart?** None. Test only.
- **Ledger line?** No. No line misbehaved.

## Asks for the orchestrator

None. No paid model and no kiosk read were needed.

For whoever reads this job: this session was started as a resume, but no handoff for this test existed. The `HANDOFF.md` at the worktree root is main's tracked music note, so it was left in place, as the sibling also did.
