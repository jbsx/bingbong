---
test: e2e/taskProgress.e2e.test.ts:47
slug: taskProgress-47
status: confirmed
class: stale-test
cause_key: the scripted hub Task has two gaps, each enough alone: the stand-in never answers a hop's `passage` Choice (#401), so the hop reads malformed; and since #485 a line is asked on the Appliance Card first, so a decisionScript entry in page-card labels is consumed there and reads malformed
same_as: none (the second gap is #518's cause, in a different file; #518's change does not cure this test)
---

# The scripted hub Task never reaches its second hop: the stand-in does not answer `passage` (#401), and the Appliance Card takes the Task's first reading (#485)

Part of #517.

The test is out of date and the app is right. The Task progress bar works on the shipped road: once the script is corrected, the bar reads `forward held back forward full` and ends at 100 with the Appliance Card on. The change is in the e2e stand-in only, and no file under `src/` changes. It also cures `taskProgress:73` (AC3), which reads the Feed entry this walk writes. `taskProgress:82` was never red.

**Scenario:** question (ask a question and get an answer), yield 10, state `partly` (`docs/agents/yield.md`, rerun 2026-10-24 on main 20f843b5). This changes nothing the owner hears and not the row's state. It puts back the e2e guard on the Task's progress bar and on the Feed's closer/unsure/no closer lines, which has guarded nothing since 2026-10-23.

## Root cause

There are two independent gaps. Either one alone keeps the test red, so the fix needs both.

1. **The test waits for a five-move bar.** `e2e/taskProgress.e2e.test.ts:47` polls `.task-bar`'s `data-moves` for `forward held back forward full`. Each move needs a hop's reading, so the Task has to walk all five readings of `hubTaskReadings()` (`e2e/scriptedJev.ts:55`).
2. **Gap A, the older one: a hop's `passage` goes unanswered.** Since `ad848423` (#401, 2026-10-23) a hop over a page with text in view also asks the passage Choice (`src/core/command/jevReading.ts:1525`, added at `:1653`). `decisionScript` (`e2e/scriptedJev.ts:70-87`) has no `passage`. `readDecisionAnswers` needs every question answered (`src/core/ports/decisionModel.ts:195-203`), so the stand-in reads `malformed` (`src/main/decision/createDecisionModel.ts:92`). The hop ends `unavailable` (`src/main/run/commandRunner.ts:2953-2961`) after one action. `e2e/scriptedJev.test.ts` could not see this: its hop ask is on a page with no `viewportText`, so `passageQuestion` returns null.
3. **Gap B, the newer one: the Appliance Card takes the first reading.** Since `a2297959` (#485, 2026-10-27) this line is asked on the Appliance Card first (`src/main/run/commandRunner.ts:1347`). The script's first entry is `click-1`, a page-card label, so that ask consumes it and reads `malformed`. A failed Appliance Card ask goes on to the page card (`commandRunner.ts:1358`), which now takes the second entry, `back`. So the Task's first action is the browser's `back`, not hub Aurora's link, and it ends after that action.
4. **What the failure shows.** The bar never reaches the five moves, so the wait runs out at 40 s with only `waitFor timed out`. AC3 then finds `[[],["back"]]` in the Feed.

Gap B is the cause in #518, but #518 only changes `e2e/mediaOps.e2e.test.ts`, so it does not reach this script. Gap A is new to this finding.

## Evidence

All under Xvfb on the scripted stand-in. Nothing reached a real host or real Jev. The failure at `c35c75b1` is the same as #517's at `4ba056aa`: line 47, 40000 ms timeout, and the same `[[],["back"]]`.

Decision records at `c35c75b1`, unchanged script:

```json
{"transcript":"what defect rate did hub aurora return","reading":"jev","verb":"back","card":"page","ended":"wall","appliance":{"ask":"turn-mvvavn26-2-appliance","jev":{"reason":"malformed"}}}
```

With only the `page` entry added, the first click is right and the next hop fails. Its ask carries `action, slot, extent, amount, where, kind, outcome, progress, passage`:

```json
{"transcript":"what defect rate did hub aurora return","task":{"hop":1},"verb":"none","jev":{"model":"scripted","reason":"malformed"},"ended":"unavailable"}
```

**Arms at `c35c75b1`.** The "Both reverted" row is the revert after the green runs. All runs except the first "Unchanged" whole-file run and the final patch's carried a throwaway record dump in the test's `afterAll`.

| Script | Whole file | AC2 alone | Feed at AC3 |
|---|---|---|---|
| Unchanged | red 1 of 1 | red 1 of 1 | `[[],["back"]]` |
| `page` entry only | red 2 of 2 | red 1 of 1 | `[[],["click [1] \"Regional hub Aurora\""]]` |
| `passage` only | red 1 of 1 | not run | `[[],["back"]]` |
| Both | **green 2 of 2** (3 of 3 tests) | **green 1 of 1** | four action lines |
| Both reverted | red 1 of 1 | not run | `[[],["back"]]` |
| Final patch, inside the reach run below | green 1 of 1 | not run | four action lines |

Whole file and alone agree in every arm where both ran, so no earlier test's state is involved. No arm gave different results across its runs, so this is not a timing flake.

**History**, each commit built and run, whole file:

| Commit | Script | Result |
|---|---|---|
| `44e21b45` (parent of #401) | as it was | green 3 of 3 |
| `ad848423` (#401) | as it was | red, `click [1]` only: **Gap A's first bad** |
| `7f1eab55` (parent of #485) | as it was | red, `click [1]` only |
| `7f1eab55` | `passage` answered | green 3 of 3 |
| `a2297959` (#485) | `passage` answered | red, `back`: **Gap B's first bad** |
| `a2297959` | as it was | red, `back` |

**Guards.** `e2e/scriptedJev.test.ts` with the patch: 4 of 4 pass. With `passage` removed: 1 fails (`expected 'unavailable' to be 'answered'`). With the `page` entry removed: 1 fails (`the Appliance Card's ask read unavailable`). `pnpm typecheck` is clean.

**Reach.** The final patch ran once over all 17 `e2e/*.e2e.test.ts` files that use `decisionScript`: 16 tests failed, 42 passed, 35 skipped.

- **Nothing newly red.** All 16 reds are in #517's table: `mediaOps` 4, `upload` 4, `idleMusic` 3, `pageMusic` 2, `idlePromptMusic` 2, `appOps` 1.
- **Green files:** `taskProgress` 3 of 3, plus `audioRoad`, `peekCard`, `stageFeedback`, `stateShots`, `turnCard`. `stageFeedback` is called a flake by its own finding, so its green here says nothing about this patch. `turnCard` was already green without any patch in `appOps-65`'s runs.
- **Skipped by their own gates, so not exercised:** `music`, `idleShot`, `youtube`, `idleCpu`, `playTiming`.
- **`stateShots`** also uses `hubTaskReadings` and stays green, but it asserts nothing about the walk and I did not look at its `22-task-progress` shot.

## The change

The diff is in `taskProgress-47.patch`. It is two files, and it was made at `c35c75b1`.

- **`e2e/scriptedJev.ts`, `hubTaskReadings()`:** add `readingOf(HUB_TASK_LINE, 'page')` as the first entry, and say why in the doc comment.
- **`e2e/scriptedJev.ts`, `decisionScript`:** add `passage: choice('none')` beside `kind`, and add one sentence to the doc comment. An answer to a question not asked is ignored (`readDecisionAnswers` reads only the questions), so asks with no passage are unchanged.
- **`e2e/scriptedJev.test.ts`:** add two tests. One builds a hop ask over a page with `viewportText` and asserts `passage` is asked and answered. The other runs `hubTaskReadings()` through an Appliance Card ask, which must read `page`, then a page-card ask, which must read `click-1`.

`e2e/taskProgress.e2e.test.ts` does not change: its assertions are still what #375 meant.

Do not set `BINGBONG_APPLIANCE_CARD=off`, and do not make the stand-in translate old labels or answer missing questions by itself. Either would prove a road the app does not ship, or take away the check that a new question gets scripted.

No stage, wait, word or sentence is added, so no Tier or UI principle applies. The input-to-output chart is not affected: test code only.

## Acceptance criteria

- [ ] All 3 tests in `e2e/taskProgress.e2e.test.ts` pass in a whole-file run, and AC2 passes alone, with no env switch.
- [ ] AC2 still asserts the whole history `forward held back forward full`, `filled: '100'`, the mid-Task prefixes, and the bar standing once the Task ends. AC3 still asserts the four lines' readings.
- [ ] `e2e/scriptedJev.test.ts` fails if `passage` is removed from `decisionScript`, and fails if the `page` entry is removed from `hubTaskReadings`.
- [ ] No test in the other `decisionScript` files goes newly red.
- [ ] The commit names both reasons: the stand-in never answered #401's passage, and #485 put the Appliance Card's ask first.
- [ ] No file under `src/` changes.

## Not in this issue

- **What a real model picks for this line.** The script's `page` says nothing about what Jev reads on the Appliance Card for a question about the page open. This line has not been asked of a real model here; that is the gate's to measure.
- **A scripted Answer Passage.** No scripted Task says one, so `passage` is a constant `none`. Add a `passage` field to `Reading` when a test needs one.
- **`dismiss`.** The stand-in does not answer the dismiss Choice on a hop over a pop-up either. `scriptedJev.test.ts` scopes itself to "a page without a pop-up", and no red here reaches it. I did not check whether another suite does.
- **The other reds still red under this patch** (`mediaOps`, `upload`, `idleMusic`, `pageMusic`, `idlePromptMusic`, `appOps`) have their own findings.

## Dependencies

None. No `Blocked by` edge. I read #517 and #518 in full, and only the titles of the other open issues (#516, #512, #490, #469, #452, #439, #415).

`appOps-65`'s patch adds `fate: choice('goes_on')` on the neighbouring line of `decisionScript`, so whichever lands second has a one-line conflict to resolve, keeping both. That is a merge note, not a dependency: this test needs no Fate, since it waits for `idle()` before its line and the recorded Appliance Card ask carries no `fate`.

## Grill

`grill-with-docs` is not in this session's skill list. I loaded `grilling` and answered each question myself. I did not load `domain-modeling`, since no term or ADR changes.

- **App or test?** Test. #485's commit says a line goes to the Appliance Card first, and #401's says a Verdict asks the passage. The bar and Feed work on the shipped road once scripted (both-fixes arm).
- **Is the `back` in the failure a real bug?** No. It is the second script entry landing on the page card. No model chose it.
- **Is one gap enough to fix?** No. Each single-fix arm stays red.
- **Which label for the Appliance Card's reading: `page` or `none`?** `page`. The card's own instruction says to choose `page` when the words are about something on the page open, and this line is. Both send the line on, so the owner cannot feel the difference in a test-only value. It is no tie, and `none` was not built.
- **Which passage answer: `none` or a `view-N`?** `none`. No test asserts a said passage, and `view-N` is not on every page. A label a page does not offer has no effect here, but `none` is on every passage question.
- **Where does the `page` entry go: the helper or the test's call?** The helper. `stateShots` walks the same Task from the same readings, and the code beside it keeps the walk in one place.
- **Is `passage` scripted per reading or always?** Always, as `kind` and `steps` are. The doc comment on `decisionScript` already promises every question is answered.
- **Should the test fail faster than 40 s, as `appOps-65` does with `not a command: `?** No. The two new unit tests catch both gaps in under a second, and a Task has no one CLI line to match. The test stays as it is.
- **Does this overlap #518?** Same cause for Gap B, different file. Neither change cures the other's tests; either can land first.
- **Yield, Tier, UI, chart?** Answered above: no scenario change, no stage, no word or sentence, no chart change.
