---
test: e2e/upload.e2e.test.ts:103
slug: upload-103
status: confirmed
class: stale-test
cause_key: since #485 a line the Local Match cannot settle is asked on the Appliance Card first, so a decisionScript in page-card labels has its entry consumed by the Appliance Card ask, which reads malformed
same_as: #518
---

# e2e/upload still scripts the page card: since #485 the Appliance Card takes the line's first entry, so the click never fires and no chooser opens

Part of #517. Same cause as #518, in a different file, so #518's change does not reach it.

The test is out of date; the app is right. ADR 0096 (#485) put the Appliance Card ahead of the page card, and this suite's script was never moved. Test change only; nothing under `src/` changes. The file's other three reds (lines 117, 126 and 133) go red at the same commit and turn green with the same change. I read the failing records for line 103 only; those three have their own findings to prove.

**Scenario:** upload by voice has no row on the Yield list (`docs/agents/yield.md` has no upload scenario). The nearest row is `goal` (yield 4, `partly`, `pnpm goal:gate` 2026-10-27), whose outcomes it serves. No change to any scenario or its state: it restores the e2e guard on the chooser-to-field road (#424, ADR 0092), which has guarded nothing since #485.

## How this test differs from #518

The first three links match #518. The last one does not, because this script has two entries per line, not one:

1. The Appliance Card ask (`cli-2-…-appliance`) takes entry 1, `click-1`. Its card has no such option, so it reads `malformed`.
2. The page card ask takes entry 2, the one meant for the Shelf ask: `action: none`. It is answered, not `failed` as in #518. Its record is `{"reading":"jev","verb":"none","card":"page","appliance":{"jev":{"reason":"malformed"}}}`.
3. A hop-0 `none` asks again (ADR 0082). That `-where` ask finds the script empty and reads `failed`, and the line ends `unavailable`: `{"reading":"best_guess","verb":"none","jev":{"reason":"failed"},"ask":"cli-2-…-where","ended":"unavailable"}`.
4. Nothing was clicked, so no chooser opened and no Shelf ask was made. The asks log holds `appliance`, `command` and `where`, and no `shelf`. `cli()` at line 103 waits on `/^(clicked \[1\]|error:)/`, which no output matches, so it times out at 20 s with only `waitFor timed out`.

The Fate gap in `appOps-65` is not involved. No ask carries `fate` in the two runs whose asks I read: this test alone unchanged, and the whole file with the first probe. So no line in the fixed file is read over a running one.

## Evidence

All at `c35c75b1` under Xvfb on the scripted stand-in, except the two base runs at the commits named. Nothing reached a real host. The failure matches #517's at `4ba056aa`: line 103, `waitFor` timeout of 20000 ms.

| Run | Whole file | Alone (`-t 'upload the invoice'`) |
|---|---|---|
| Unchanged | red 1 of 1 (4 failed, 1 passed) | red 1 of 1 |
| Script with `page` first, first probe | green 1 of 1 (5 passed) | not run |
| Final patch | green 2 of 2 (5 passed) | green 2 of 2 |
| Patch reverted | red 1 of 1 (4 failed, 1 passed) | red 1 of 1 |

The records with the first probe show every line reading `card: 'page'`, `appliance.chose: 'page'`, with `upload` holding `invoice.pdf`, `me.png`, `null` (reason `none`) and `notes.txt`. Each line makes three asks, `appliance`, `command` and `shelf`.

**Start of the failure, unchanged test built at each commit (whole file):**

| Commit | Result |
|---|---|
| `7f1eab55` (parent of #485) | 5 passed |
| `a2297959` (#485) | 4 failed, 1 passed |

**Why this is not an app bug:** the corpus already expects this road. `fixtures/jev-cases/shelf-upload-the-invoice-i-downloaded-card-appliance.json` and the `attach-my-cv` and `attach-the-screenshot` equivalents want `page|none` on the Appliance Card, then `click-N` on the page card, then the file on the Shelf ask.

The probe does not break a sibling: the file's other tests are green with it. `pnpm typecheck` and eslint on the patched file report no errors.

## The change

In `e2e/upload.e2e.test.ts` only. Patch: `findings/upload-103.patch`.

- In `decisionScript`, put `readingOf(LINES.<line>, 'page')` before each line's `click-N` entry, for all four lines, so each line has three entries. Update the comment to: "Each line is three asks: the Appliance Card, whose `page` sends it on (#485); the page card; the Shelf's."
- Add `card?: string` and `appliance?: { chose?: string }` to `DecisionLine`.
- In the invoice test, also expect `card: 'page'` and `appliance: { chose: 'page' }` in the record.
- In the invoice test, take `const since = harness.cliMark()` before the `cli` call, and add `await harness.waitForCliOutput(/^said: "Attached invoice\.pdf\."$/, { since })`. The title promises "the file is said" and nothing asserted it.

Do not set `BINGBONG_APPLIANCE_CARD=off`, and do not make the stand-in translate labels: either would prove a road the app does not ship by default.

No stage, wait, word or sentence is added, so no Tier, UI or chart change applies. The input-to-output flow does not change.

## Acceptance criteria

- [ ] All 5 tests in `e2e/upload.e2e.test.ts` pass with the Appliance Card on, whole file and alone.
- [ ] The invoice test asserts the Appliance Card's `page` pick, the page card's click, the file on the field, the site's `change`, nothing submitted, no OS dialog, one Shelf ask, and the said line.
- [ ] The commit names the reason: the expectation went out of date with #485.
- [ ] No file under `src/` changes.

## Not in this issue

- `attach a photo of me` and `put the notes on it instead` have no Appliance Card case in the corpus; the three `shelf-*` lines do. The script assumes `page` for them, so a green test says nothing about what a real model picks. A case has to come from a real line, so none is built here.
- `cli()` prints nothing useful on a line that never fires: the reds report only `waitFor timed out`. This is the same blindness #518 and `appOps-65` hit.

## Dependencies

No blocking edges. I read the open issues on 2026-10-30 and filtered their titles for upload, Shelf, e2e, Fate, script and stand-in: only #517 and #518 matched. This can land before or after #518, since the two touch different files.

## Grill

The listed `grill-with-docs` skill was not available in this session, so I loaded `mattpocock-skills:grilling` and answered its questions myself, as the brief says.

- **App or test?** Test. ADR 0096 and the `shelf-*-card-appliance` corpus cases rule that these lines go through the Appliance Card first.
- **Is `page` or `none` the right scripted answer on the Appliance Card?** `page`. Both go on to the page card, and the corpus accepts both, but `page` is the card's own option for "something on the page open" and #518 scripts it too. The test does not depend on the difference.
- **Should the script's labels change, or the stand-in?** The script. #518 rules out translating in the stand-in.
- **Does this need `fate` from `appOps-65`?** No, by the asks log above. Either order of landing works.
- **Should line 103's regex also match `not a command:`, as `appOps-65` does?** No. It would swap a 20 s timeout for a 10 s one in `recordOf`, with no better message.
- **Is the `said:` assert in scope?** Yes. It is one line, the title already claims it, and the final patch passes with it.
- **Does a tie need measuring?** No. No fork here changes what the owner hears or how fast.
- **Is `HANDOFF.md` this job's handoff?** No. The file at the worktree root is the orchestrator's from main (`bfd8b13e`, music orchestration 2026-10-29), and no handoff commit sits on this branch. I left it in place rather than delete it, per the standing rule to never remove it.
