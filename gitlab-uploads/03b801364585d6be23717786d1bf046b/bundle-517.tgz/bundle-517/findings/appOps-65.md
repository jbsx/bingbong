---
test: e2e/appOps.e2e.test.ts:65
slug: appOps-65
status: confirmed
class: stale-test
cause_key: the scripted stand-in never answers the Fate question the Appliance Card asks over a running line (#489), and since #490 a sentence still sounding is a running line, so a line typed over it reads malformed and prints "not a command"
same_as: none
---

# The e2e stand-in does not answer the Fate question, so any line typed while the last line's sentence still sounds reads `malformed`

Part of #517.

The test harness is out of date; the app is right. `decisionScript` promises an answer to every question an ask may carry, and it has never answered `fate`. The change is test-side only. The `open settings` test (title at line 115, failing `waitFor` at line 65, called from line 116) is the first line after a `navigate` to an empty page, so it arrives while that line's sentence still sounds. No file under `src/` changes.

**Scenario:** panel (control the app itself: hide a panel, open settings), yield 6, state `partly` (`docs/agents/yield.md`, live 2026-10-24 on 2eb50a79 + #420). This changes nothing the owner hears and not the row's state. It restores the e2e guard on `open settings` showing the Settings view, and lets any scripted suite type a line over a running one.

## Root cause

1. **The first line follows a navigate that speaks.** `beforeAll` navigates to `fixture.url('/')` (`e2e/appOps.e2e.test.ts:104-106`), a page with one input and no text. The landing is suspected empty (`src/main/run/commandRunner.ts:2218-2219`), so the Task goes on to a hop. The script has no entry for the `navigate` line, so that ask reads `failed` and the Task ends `wall`, saying "This page shows no text." (`commandRunner.ts:2957-2960`).
2. **A sounding sentence is a running line.** Since `86d0fbd5` (#490, the ruling on item 1, 2026-10-28) a line whose sentence still sounds stays running at the Speaking stage (`commandRunner.ts:750-757`). This was ruled and is correct. Its commit message: "a Page Read, or any line that speaks, counts as the running Command on the Appliance Card while its sentence sounds".
3. **The next line is read against it.** `cli` returns on `navigated:`, and the test types `open settings` at once. The recorded ask's state has `Still running … "navigate http://127.0.0.1:…/"`, `Its stage: Speaking`, and the questions `action, fate, slot, amount, where, kind`. The Fate question comes from #489 (`136cb98b`, ADR 0097).
4. **The stand-in cannot answer it.** `decisionScript` (`e2e/scriptedJev.ts:69-85`) has no `fate`. `readDecisionAnswers` needs every question answered, so it returns null and the stand-in reads `malformed` (`src/main/decision/createDecisionModel.ts:91-92`). This is the same class as `a8e0a453`, where #383's Extent was never scripted. `e2e/scriptedJev.test.ts` covers the first ask and the hop ask, but no Appliance Card ask, so it could not see this.
5. **The app does what #504 ruled for an unread line.** A failed ask over a running Command becomes `UNREAD` (`commandRunner.ts:1352-1353`), and the CLI prints `not a command: "open settings"`. `ANSWERED` (`e2e/appOps.e2e.test.ts:53`) does not match that, so the test waits out 20 s and reports only `waitFor timed out`.

The stand-in's gap dates from #489. It went red at #490, the first commit that made this line's moment an Overlap.

## Evidence

All under Xvfb on the scripted stand-in. Nothing reached a real host.

**The failure is the same as #517's at `4ba056aa`:** line 65, `waitFor` timeout of 20000 ms.

Record at `c35c75b1`:

```json
{"transcript":"open settings","reading":"best_guess","verb":"none","jev":{"model":"scripted","reason":"malformed"},"ask":"cli-2-…-appliance","card":"appliance","ended":"unavailable"}
```

CLI output: `said: "This page shows no text. Try “back”."`, then `not a command: "open settings"`.

| Run at `c35c75b1` | Result |
|---|---|
| Unchanged, whole file | red 2 of 2 (the other 5 tests pass) |
| Unchanged, `-t 'open settings'` alone | red 1 of 1, so no earlier test's state is involved |
| `fate: choice('goes_on')` in the stand-in, whole file | green 2 of 2 |
| Same, alone | green 1 of 1 |
| That line reverted, whole file and alone | red again, 1 of 1 each (one of the whole-file reds and the alone red above) |
| Arm B: unchanged stand-in, a throwaway 10 s wait after the navigate, whole file | green 1 of 1: the line no longer lands on the running one |
| Final patch, whole file | green 1 of 1 |
| `not a command: ` added to `ANSWERED`, stand-in unchanged | red 1 of 1 at 2.6 s, not 20 s: `open settings: expected [ { type: 'decision', … } ] to match object [ { verb: 'app', ended: 'terminal' } ]` |
| New unit test in `e2e/scriptedJev.test.ts` | fails without the stand-in line (`expected 'unavailable' to be 'answered'`), passes with it |

**Bisect** with `git bisect run` on `-t 'open settings'`, built at each commit. These are the runs named in this finding:

| Commit | Result |
|---|---|
| `8082ab7d` (before #489), whole file | green 6 of 6 |
| `136cb98b` (#489), whole file | green 6 of 6 |
| `46af5cc5` (parent of the first bad) | green |
| `86d0fbd5` (#490) | **red, first bad** |

**Reach of the patch.** It ran over all 17 `e2e/*.e2e.test.ts` files that use `decisionScript`, and no test went newly red.

- **Still red, all already in #517's table:** `idleMusic` 3, `idlePromptMusic` 2, `pageMusic` 2, `taskProgress` 2, `mediaOps` 4, `upload` 4.
- **Green:** `appOps` 6 of 6, `audioRoad`, `peekCard`, `stateShots`, `turnCard`.
- **Skipped entirely by their own gates, so not exercised:** `music`, `idleShot`, `youtube`, `idleCpu`, `playTiming`.
- **The patch cures no other red.**
  - `stageFeedback`'s slow-navigate test was green once with the patch, then red 1 of 1 with it and red 2 of 2 without it. It is flaky or separately broken, not helped by this.
  - `turnCard` is green at `c35c75b1` with the patch (2 of 2) and without it (2 of 2).

## The change

The diff is in `appOps-65.patch`.

- **`e2e/scriptedJev.ts`, `decisionScript`:** add `fate: choice('goes_on')` beside `kind`, and say why in the doc comment. Extra answers are ignored when no Fate is asked, so asks with nothing running are unchanged.
- **`e2e/scriptedJev.test.ts`:** add a test that builds an Appliance Card ask with a `running` line, asserts `fate` is among its questions, and asserts the stand-in answers it.
- **`e2e/appOps.e2e.test.ts:53`:** add `not a command: ` to `ANSWERED`, so a miss fails at once on the record rather than as a 20 s timeout.

Do not set a switch off, do not add a wait after the navigate, and do not change the fixture page. Each would make this test pass by stepping off the Overlap road the app ships.

No stage, wait, word or sentence is added, so no Tier or UI principle applies. The input-to-output chart is not affected: test code only.

## Acceptance criteria

- [ ] All 6 tests in `e2e/appOps.e2e.test.ts` pass in a whole-file run and `open settings` alone, with no env switch.
- [ ] The test still asserts the Settings view in the dashboard, one record `verb: 'app', ended: 'terminal'`, the pane on its page, and the card's `show_settings` and `settings` lines.
- [ ] `e2e/scriptedJev.test.ts` fails if `fate` is removed from `decisionScript`.
- [ ] No test in the other `decisionScript` files goes newly red.
- [ ] The commit names the reason: the stand-in never answered the Fate (#489), and #490 made this line an Overlap.
- [ ] No file under `src/` changes.

## Not in this issue

- **What a real model reads here.** The stand-in's `goes_on` says nothing about the Fate Jev would pick for `open settings` over a sounding sentence. That is the Overlap gate's to measure.
- **A scripted Fate per reading.** No test needs a value other than `goes_on` yet. Add a `fate` field to `Reading` when one does.
- **`stageFeedback`'s slow-navigate test** passed once in 4 runs at `c35c75b1` (1 of 2 with the patch, 0 of 2 without), so it is flaky. Its own finding should say why.
- **`turnCard`** is in #517's table but was green 4 of 4 here. Its own finding should say why.

## Dependencies

None. No `Blocked by` edge. #490 stays open, but the rule this rests on has landed and does not wait on it. I read #517 and #518 in full, and only the titles of the other open issues (#516, #512, #490, #469, #452, #439, #415).

## Grill

`grill-with-docs` is not in this session's skill list. I loaded `grilling` and answered each question myself. I did not load `domain-modeling`, since no term or ADR changes.

- **App or test?** Test. ADR 0097 says a line given while another runs is read against it, and the #490 ruling says a sounding sentence is a running line. The app did what those rulings say; only the stand-in fell short.
- **Should a line wait out the sentence, or be read at once?** Read at once: "Arrival ends nothing" (ADR 0097).
- **Is "not a command" on a malformed ask an app bug?** No. #504 rules that a failed read over a running line goes to the grammar. A real host answers `fate`; only the stand-in cannot.
- **Stand-in answer, or a wait in the test?** Stand-in. The comment on `decisionScript` already promises every question is answered, and `a8e0a453` fixed the same class the same way. A wait would hide the gap from every other suite and take the test off the Overlap road. The code beside it decides this, so it is not a tie.
- **`goes_on` or `ends`?** `goes_on`. It is what `readFate` reads when unsure or unanswered (`src/core/command/runningCommand.ts:175-180`), so it adds no behaviour of its own. The owner cannot feel the difference in a test-only value, so it is no tie to measure, and `ends` was not built.
- **Where does the guard go?** `e2e/scriptedJev.test.ts`, which exists to hold this promise. Its comment names the same audit.
- **Does the fixture page need text?** No. The empty page is what makes this line an Overlap, and that road is real. Leave it.
- **Does it touch #518's change?** No. #518 changes `e2e/mediaOps.e2e.test.ts` only, and this patch does not touch that file. Either can land first.
- **Yield, Tier, UI, chart?** Answered above: no scenario change, no stage, no word or sentence, no chart change.
