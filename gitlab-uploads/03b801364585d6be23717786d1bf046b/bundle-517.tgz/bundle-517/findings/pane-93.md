---
test: e2e/pane.e2e.test.ts:93
slug: pane-93
status: confirmed
class: stale-test
cause_key: since #485 an exact `click N` with no page in hand fires with no collect, so on a page the URL bar opened no number was ever shown and ADR 0033 refuses it; the confirm is never raised
same_as: none
---

# e2e/pane's confirm test opens its page by the URL bar, so since #485 nothing has shown `click 2` its number and the click is refused before the confirm opens

Part of #517.

The test is out of date and the Site Question works. The test's `click 2` relied on a page collect that #485 removed from exact lines on purpose. The click is now refused, so the page never asks, and the test waits 20 s for a question that was never raised. With the page opened by a Command, the whole road passes unchanged: the question is said, "yes" answers it and the page gets `true`. Test change only, nothing under `src/`.

**Scenario:** `wall` (get past a wall: cookie banner, pop-up, consent-or-pay, sign-in) is the nearest row, yield 6, state `partly` (evidence 2026-10-24 in `docs/agents/yield.md`). A native confirm has no row of its own. This does not change what the owner hears or the scenario's state. It puts back the e2e guard on the Site Question (#423), which has guarded nothing since #485 (2026-10-27).

## Root cause

1. The test opens the page with `harness.navigatePane` (`e2e/pane.e2e.test.ts:90`), the URL bar. That is no Command, so nothing collects the page.
2. Since `a2297959` (#485), an exact line with no page in hand fires with no collect (`src/main/run/commandRunner.ts:1336-1338`). The commit message says so: "with none in hand the line fires (reliability.md rule 1)". The unit test `commandRunner.test.ts:5449` pins it for `scroll down`.
3. `resolveRef` (`src/main/browser/createCdpBrowserController.ts:1909-1911`) collects for itself, but that collect marks nothing as shown. Only `markShown` does (`:1203`, `:1886`, `:1938`, `:2985`), so `refIsShown` answers false.
4. The controller refuses the number (`:574`), as ADR 0033 decides: "A number with no shown node — past anything a read printed, or a guess — is refused". The decision record has `"verb":"click","target":2,"jevAsked":false,"error":"ref 2 refused: it no longer names the element you were shown…"`, and the page carried with that refusal lists `[2] button "Ask confirm"`.
5. The Command ends on `There's no item 2 on this page.` (`src/core/command/spokenFailure.ts:90`). The button was never clicked, `window.__confirmAnswer` stays null and the Feed never gets `The page asks: really proceed? Yes or no?`. The `waitFor` at `:93` times out.

Before #485 the same line went through the page card's collect (`collectPage`, which marks the numbers shown at `:2985`). The test depended on that side effect without saying so.

## Evidence

All at `c35c75b1` under Xvfb on the scripted stand-in unless a sha is named. No real host and no model was reached (`jevAsked: false` on every record).

| Run | Result |
|---|---|
| Unchanged, whole file | red 2 of 2 (7 others pass) |
| Unchanged, alone | red 3 of 3, including after the probe was reverted |
| `7f1eab55`, the parent of `a2297959`, alone | green 1 of 1 |
| `a2297959`, alone | red 1 of 1, same line, same 20 s |
| Arm A, the change below, whole file | green 3 of 3, 8 of 8 tests each time |
| Arm A, alone | green 1 of 1 |
| Arm B, `click ask confirm`, whole file | green 1 of 1, 8 of 8 tests |
| Probe P, app side, alone | green 1 of 1, then red again on revert |

- **Not run at `4ba056aa`.** The failure there is the same line and the same 20 s as at `c35c75b1`. The commits between them change `commandRunner.ts` (a1343fef takes `read` out of `exactOf`), but not the no-page-in-hand branch, and they do not touch `resolveRef`, `refIsShown` or `markShown`.
- **Probe P** added one line in `read()`: an exact line with a target and no page in hand goes to the page card's collect. It is what proves the missing collect is the link. It is not a candidate fix (see Grill).
- **Arm A's records** show the full road:
  - `{"type":"site_answer","transcript":"yes","question":{"kind":"confirm","text":"really proceed?"},"raisedBy":"click 2","answer":"accept","reading":"local_match","jevAsked":false}`
  - Feed: `click 2 click [2] "Ask confirm"`, `The page asks: really proceed? Yes or no?`, `yes answer the page's question: OK`, `Answered OK.`

## The change

In `e2e/pane.e2e.test.ts`, the test `says the page's confirm…` only (`pane-93.patch` is this diff):

- Replace `await harness.navigatePane(harness.fixture.url('/native-dialog'))` with ``await submitAndAwaitAnswer(harness, `navigate ${harness.fixture.url('/native-dialog')}`, 'Opened')``.
- Add `submitAndAwaitAnswer` to the import from `./feed`.
- Add this comment above it: `// By a Command, not the URL bar: its outcome is what shows the page's numbers (ADR 0033), and since #485 an exact `click 2` collects nothing itself.`
- Leave `click 2`, `yes` and both `waitFor`s as they are.

No switch is set and the harness does not change.

## Acceptance criteria

- [ ] The test passes in the whole file and alone, with the other 7 tests in the file still green.
- [ ] It still fires the exact line `click 2`, and still asserts both the Feed's `The page asks: really proceed? Yes or no?` and `window.__confirmAnswer === true` on the page.
- [ ] The commit names the reason: the test relied on a collect that #485 took off exact lines.
- [ ] No file under `src/` changes. The chart is not touched, because the input-to-output flow does not change.

## Not in this issue

- **A false sentence.** A typed `click 2` on a page no Command has collected says `There's no item 2 on this page.` while the page has an item 2 (`spokenFailure.ts:90` reads every ref refusal as a missing item). Per ADR 0033 the refusal stands; only the words are wrong. It needs its own line in the Failed Lines ledger if it is ever hit on a real line. From the code alone, not run: the refusal marks the page shown (`:1938`), so saying `click 2` again would fire.
- **Not checked:** whether a spoken `click N` can hit the same refusal when the speech-start collect has not settled. `pageInHand` does not wait for that collect.

## Dependencies

Blocks nothing and is blocked by nothing. Open issues read: #518, #517, #516, #512, #490, #469, #452, #439, #415.

## Grill

The brief's `grill-with-docs` skill is not installed here, so this used `grilling` and answered each question from the docs and the runs.

- **Is this a test that guards behaviour the app has lost?** No. The Site Question road passes end to end in Arm A. What went is typed `click N` on a page never collected, which only worked through a side effect, and ADR 0033 calls such a number a guess.
- **Should the app collect before an exact `click N` (Probe P)?** No. Reliability rule 1 says an exact line fires on its words, before the page collect, and #485 says the same. P adds a stage to a line the rule keeps free of one.
- **Should the controller's own collect count as shown (a second app arm)?** No. That contradicts ADR 0033's "or a guess", so it was not built. Changing it would be the owner's ADR change, and nothing in this test asks for it.
- **Arm A or Arm B?** Arm A, by rule rather than by measure: both are green, and the brief says a test must prove the road the app ships by default. Arm B's `click ask confirm` passes only because the hermetic harness has no model; with Jev armed that line goes to the Appliance Card. Arm A's exact line takes one road with or without Jev. The owner would not feel this fork, because it is test setup.
- **Why wait on `Opened` and not the pane's URL?** The numbers are marked shown as the Command's outcome is built, before its Answer. A wait on the URL could fire `click 2` before then, or supersede the `navigate`. The Feed in Arm A reads `Opened native dialog fixture.`, so the marker holds.
- **Does the change add a stage, a wait, a state, a word or a sentence?** No. No Command's path changes, so there is no Tier or Felt Reaction to report, and no UI principle is touched.
- **Should the test also assert the `raisedBy` record?** No. The test's title promises the said question and the answer on the page, and both are already asserted. Adding it would widen the test past what broke.
- **Does the false sentence belong here?** No. It is a separate defect in other code, and this test passes without it being fixed.
