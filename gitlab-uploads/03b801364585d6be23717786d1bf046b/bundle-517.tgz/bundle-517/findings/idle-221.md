---
test: e2e/idle.e2e.test.ts:221
slug: idle-221
status: confirmed
class: app-bug
cause_key: the Turn Card's fold stays open for the Peek Card's strip, and App shows any open fold whenever the Idle Screen is up, so a line whose card went with a wake comes back over the screen for the rest of its 15 s, and its scrim takes the tap
same_as: none
---

# A Turn Card that went with a wake comes back when the Idle Screen does, and its scrim takes the next tap

Part of #517.

The app is wrong, not the test. CONTEXT.md says a Command that acts on the pane wakes the screen "and the card goes with it", and that the card is up from "the wake word or a typed Idle Prompt line". But when the Idle Screen comes back within 15 s of that line ending, the line's finished card is drawn again over a dimmed screen. The scrim then takes the next tap: a tap on a Top Repos row wakes the screen and opens nothing. The test has been red since the Turn Card landed (`a60a28fa`, #474, 2026-10-26). Waiting the card out in the test does not fix it, because the next test goes red on the same stale card (Arm T below).

**Scenario:** `idle` (glance at the Idle Screen), yield 0, state `works` (`shot:idle`). The state does not change. This restores the e2e guard on the News card's tap, which has guarded nothing since #474, and removes a stale card and a dead tap during that 15 s window. It is not a voice fix: the road in is the Toolbar's home button or the shortcut. The voice road, `go to the idle screen` (`panel`, yield 6), measured the same before and after.

## Root cause

1. `e2e/idle.e2e.test.ts:162`, an earlier test, taps the Last Page. That runs `resume` as a Command, and the Command wakes the screen. The fold (`src/core/idle/turnCard.ts`) is open for that line and retires 15 s after its end. It stays open while the pane shows because the Peek Card's strip draws the same fold (#475).
2. `e2e/idle.e2e.test.ts:189`, seconds later, presses Ctrl+Shift+L and the Idle Screen comes back.
3. `src/renderer/src/App.tsx:200` sets `turnUp = turn.state.phase === 'open'`. Nothing asks whether this line's card already went. **This is the first thing that is wrong.** It has been this way since `a60a28fa`.
4. `src/renderer/src/IdleScreen.tsx:758` draws the card, and `src/renderer/src/TurnCard.tsx:194` draws its scrim, covering the whole screen (`styles.css:2789`, `inset: 0`, z-index 4).
5. The test's `clickDashboardElement` at line 219 lands on the scrim. The tap wakes the screen and the row's `onPointerDown` (`src/renderer/src/NewsCard.tsx:15`) never fires, so no `navigate` is sent. `waitForPaneUrl` at line 221 times out after 15 s.

## Evidence

All at `c35c75b1` unless named, under Xvfb, on the scripted stand-in. No paid model or real host was reached.

**Reproduction**
- Whole file: red 4 of 4 (one unchanged run, two with a logging probe, one as the base of the arms). The failure is the same as #517's.
- Alone with `-t`: green 1 of 1. There is no earlier `resume`, so there is no card. This is the file-order dependence.

**What the app did**, read from a probe just before the tap:
- `elementFromPoint` at the row's centre returned `DIV.turn-scrim`.
- The row itself was present and not hidden, and `.idle-screen` was up.
- The card read `{"state":"done","label":"Done Back on 127.0.0.1:40683/second.. Tap to dismiss"}`, with the history `“resume”`, `Read as resume the last page`, `Opening the last page`.
- After the tap, a capture-phase `pointerdown` listener recorded only `DIV.turn-scrim`. The screen had woken and the pane was still on `/`.

**Bisect** (whole file, one run each):

| commit | result |
|---|---|
| `a60a28fa~1` | 11 of 11 pass |
| `a60a28fa` (#474) | this test red |
| `ff852ef1` | this test red |
| `7c770a56` | this test red |

**Arms.** The fork is what to change. The measure, named before building, was `idle.e2e` whole, plus `idleByVoice`, `peekCard`, `turnCard` and `stageFeedback`. `stateShots` was run on the final arm only. All arms were run in this worktree.

| arm | what it does | result |
|---|---|---|
| Base | nothing | this test red; `stageFeedback` red (see Not in this issue) |
| T, test only | wait for `.turn-card` to go before the tap | this test green; **next test red** at its `dashboardShown` wait (idle 12 of 13) |
| W, app | remember the card on the screen's falling edge, and hide that line's card on return | this test green; **next test red**, same place (22 of 23) |
| E, app | on the screen's rising edge, hide the card of a line already over | **23 of 23**; `idle.e2e` 3 of 3 runs green |
| Final, E with the revival clause below and the test's assertion | | `idle.e2e` green; `idleByVoice`, `peekCard`, `turnCard` green; `stateShots` 13 of 13; `stageFeedback` red as on base (22 of 23) |

Winner: E. It is the only arm with nothing lost. T and W fail the next test because of the repo tap's own `navigate` line. Its card comes back when that test presses the shortcut, and its click at the centre of `.idle-screen` then lands on the card, which only closes it. That mechanism is inferred from the failing line and from `TurnCard.tsx:200`; I did not probe it separately. W also misses this line because the screen falls before the fold opens.

**The revert.** With the assertion kept and the app change removed, the test goes red at the new assertion (`expected true to be false`, `idle.e2e.test.ts:206`), failing in about 1 s rather than a 15 s timeout. Five later tests in the file then go red as well, because the assertion stops the test before the tap that wakes the screen. That cascade is the file's existing order dependence, not a new fault.

**The voice road is unchanged.** Sampling every 20 ms through `go to the idle screen`, screen and card state read the same on base and on final: `["false:none","true:acting","true:done"]`. The screen comes up mid-turn, so that line keeps its card.

`pnpm typecheck` and eslint on the two changed files are clean with the patch applied. The patch is at `/home/jbsx/.claude/jobs/7b9f65fd/tmp/findings/idle-221.patch`.

## The change

`src/renderer/src/App.tsx`:

- Beside `idleUp` (line 56), add:
  ```ts
  // The line whose card the screen came up without, by its clock zero.
  const cardGone = useRef<number | null>(null)
  ```
- Just before `idleUp.current = showIdle` (line 164), add:
  ```ts
  // The screen coming up over a line already over shows no card for it (CONTEXT.md, Turn Card): that line is the pane's, and the fold stays open for the Peek Card's strip.
  if (!idleUp.current && showIdle) cardGone.current = turn.state.phase === 'open' && turn.state.end !== null ? turn.state.openedAt : null
  ```
- At line 200, change to:
  ```ts
  const turnUp = turn.state.phase === 'open' && (turn.state.end === null || turn.state.openedAt !== cardGone.current)
  ```
  The `end === null` clause covers a hop that revives the same line after its forerunner's `done` (`turnCard.ts:208-213`). That hop keeps its `openedAt`, and a line running again must show. No e2e case exercises this clause; it comes from reading the fold.

`e2e/idle.e2e.test.ts`, after the `Top repos ★ this month` assertion (line 204), add:
```ts
// The `resume` of the Last Page's test ended seconds ago and woke the screen: its card went with it and does not come back.
expect(await harness.dashboardEval<boolean>(`!!document.querySelector('.turn-card')`)).toBe(false)
```

Do not call `turn.dismiss()` instead. Hiding leaves the fold alone, so the Peek Card's strip keeps its line if the screen wakes again within the 15 s. Do not wait the card out or dismiss it in the test: that passes on a road where the bug stays (Arm T).

Checks by AGENTS.md:
- **Jev:** no ask, card or list changes. This is by kind, for every line.
- **Reliability:** no stage is added to a Command's path, so no Felt Reaction changes.
- **UI (`docs/agents/ui.md`):** no wait, state, word or sentence is added; a stale one is removed. No principle is bent.
- **Chart:** no update. The latest version (`docs/diagrams/input-output/versions/2026-10-30-f2c21d13-no-read-verb/chart.html`) has no step for a card coming back after a wake, and the path from input to output is unchanged. I read only its Turn Card lines, so the builder should confirm this in the completion summary.

Wording proposed for the owner, for CONTEXT.md's Turn Card entry (not applied, per the rule on drafting first):

> The screen brought back over a line already over shows no card for it; a line still running keeps its card.

## Acceptance criteria

- [ ] `e2e/idle.e2e.test.ts` passes whole, three runs in a row, on the default road with no switch set.
- [ ] The test asserts `.turn-card` is absent after the shortcut, and the tap still opens `/interactive` in the pane through the row itself.
- [ ] With the `App.tsx` change removed, that assertion fails.
- [ ] `e2e/idleByVoice`, `e2e/peekCard`, `e2e/turnCard` and `e2e/stateShots` stay green.
- [ ] `go to the idle screen` over a page still shows its own card through to Done.
- [ ] A tap on the card itself still closes it with the screen left up (`peekCard`, AC3).

## Not in this issue

- A tap on a tile under a card that is rightly up still goes to the scrim and wakes the screen rather than acting on the tile. `e2e/stateShots.e2e.test.ts:655` relies on the scrim tap waking. Left as is.
- `stageFeedback` "a slow navigate says Loading…" was red on base and on final, and green on arms W and E: 2 red of 4 runs, so it looks intermittent. It is the sibling `stageFeedback-128`'s to diagnose.
- Every row on the stale card read `0.0s` (`Thinking`, `Read as`, `Opening`, `Loading`, `Done`). Unexplained; not looked into.

## Dependencies

None. Open issues read: #518, #517, #516, #512, #490, #469, #452, #439, #415. No genuine blocking edge among them.

## Grill

`grill-with-docs` is not among this session's skills, so I used `grilling`, answering each question from the docs, the code and the arms.

- **Is the test out of date, since the app differs?** No. CONTEXT.md's Turn Card entry says the card goes with the wake, and the tap on a repo is still the News card's stated behaviour (`NewsCard.tsx:86`). The test guards behaviour the app lost.
- **Does "a card shown late starts part drained" (`TurnCard.tsx:168`, `useTurnCard.ts:8`) mean a late card is intended?** No. That covers a renderer drawing a live card late (#470, `f2c21d13`). It stays true for every card still shown, and `turnCard` is green.
- **Should the fold close at the wake instead?** No. The Peek Card's strip draws the same fold across the pane after the wake (#475), so this belongs in the Idle Screen's gate.
- **Should the gate be in the fold or in `App`?** `App`. Whether the screen is up is `App`'s fact (`idleUp`), and the fold deliberately knows nothing of it.
- **Rising edge or falling edge?** Measured: rising (Arms E and W).
- **Does a line that itself brings the screen up lose its card?** No. Measured: `true:acting`, then `true:done`. The comment at `App.tsx:57-58` says the op fires mid-turn. If `done` ever won that race the card would be hidden; I did not see it in the 2 runs sampled.
- **A line still running when the shortcut is pressed?** It keeps its card (`end === null`), which fits "up until the line is over".
- **A new line after a hidden card?** `open()` sets a new `openedAt` (`turnCard.ts:171-173`), so it shows. `peekCard` covers repeated lines on the screen.
- **Hide or dismiss?** The owner would barely feel the difference and no Yield scenario is touched, so it is not a tie to measure. Code beside it decides: the fold is shared, so hide. Only hiding was built.
- **Does the Yield rule object to fixing something at yield 0?** No. #517 asks for every red to be diagnosed, and this restores a guard.

## Owner decision needed

None.
