---
test: e2e/pageMusic.e2e.test.ts:80
slug: pageMusic-80
status: confirmed
class: stale-test
cause_key: since #485 a line is asked on the Appliance Card first; a decisionScript entry in page-card labels is consumed there, reads malformed, and the page card's ask finds the script empty and reads failed
same_as: #518
---

# `pageMusic`'s "loop the song" is scripted in page-card labels, which the Appliance Card consumes since #485

Part of #517. Same cause as #518, in a different file, and the same shape as finding `idleMusic-111`. This adds two things: the commit is now bisected, and this test is the guard on a media ref's page-card line and ops on a Player-less watch page, which must survive the rewrite.

**Verdict: the test is out of date, the app is right.** With the card's own label scripted, the app loops the page's video on one ask, with no search and no page click. No file under `src/` changes.

**Scenario:** control (what is playing), yield 20, state `partly` (`docs/agents/yield.md`, spoken 2026-10-26). No change to the scenario or what the owner hears. It restores the e2e guard on looping a song the Player never started, and on that video's media ref on the page card.

## Proof for this test, at `c35c75b1`, under Xvfb

The failing line has not moved: 80, the same `waitFor` timeout of 20000 ms as #517 at `4ba056aa`.

| Run | Result |
|---|---|
| Unchanged, whole file | red 3 of 3 (2 failed, 2 passed each time; line 97 is the other red). Two of these runs carried only a throwaway line that copies the logs |
| Unchanged, `-t 'loop the song'` alone | red 1 of 1, the same timeout (see "Not in this issue") |
| Arm A: unchanged test, `BINGBONG_APPLIANCE_CARD=off` (throwaway, not the fix) | green, all 4 tests, 1 of 1 |
| Probe: the patch, whole file | this test and the new page-road test green 4 of 4; line 97's test stays red |
| Probe: the first test, this test and the new one, by `-t` | green 1 of 1 |
| Probe reverted, whole file | red again, 1 of 1 |
| Bisect: `7f1eab55` (`a2297959~1`), unchanged test | green, all 4 tests, 1 of 1 |
| Bisect: `a2297959` (#485), unchanged test | red, the same 2 tests, 1 of 1 |

**What was being waited on:** a CLI line matching `/^(loop \[\d+\]: |loop: |error:|No response|navigated:|playing:)/`. By the code (`src/main/cli/runCliHarness.ts:81`), the app prints `not a command: "loop the song"` for this record, the output `idleMusic-111` and #518 saw. This run's log does not show the app's stdout, so that line itself was not read here. The record below is what was read.

**What the app recorded:**

```json
{"transcript":"loop the song","reading":"best_guess","verb":"none","jev":{"reason":"failed"},"card":"page",
 "appliance":{"ask":"cli-2-mvv87s6g-appliance","jev":{"reason":"malformed"}},"ended":"unavailable"}
```

The asks log has both asks for the line:

- **Appliance Card:** `Playing: "Fixture Song - YouTube" playing 0:00/1:00 volume 100% loop off`. It offers `media-loop`, `media-restart`, `media-pause`, `show`, `play`, `page` and no `loop-1`.
- **Page card:** `[1] media "Fixture Song - YouTube" playing 0:00/1:00 volume 100% loop off`. It offers `loop-1`, `restart-1`, `pause-1`, `show`, `play`. So the card the test scripted is still there; the line just reaches it second.

**The chain:**

1. `e2e/pageMusic.e2e.test.ts:56` scripts `readingOf('loop the song', 'loop-1')`, one entry in a page-card label. The label dates from `1ba1e84d` (#372) and the file was last changed by `dcd233a6` (#374), both 2026-10-21.
2. `a2297959` (#485, 2026-10-27) asks the Appliance Card first (`src/main/run/commandRunner.ts:1347`). That commit's file list has no e2e file. The bisect above puts the break on this commit.
3. The stand-in removes the matching entry before reading it (`src/main/decision/createDecisionModel.ts:87`). `loop-1` is not on the card, so it reads `malformed` (line 92).
4. A `malformed` Appliance ask is `failed` with no Local Match guess to fire, so it goes on to the page card (`commandRunner.ts:1358`), where the script has nothing left for this line: `ran out of answers`, read as `failed` (`createDecisionModel.ts:88`).
5. The test's pattern does not include `not a command`, so it waits out 20 s and reports only `waitFor timed out`.

**Was this behaviour meant?** Yes. CONTEXT.md "Appliance Card": a pick fires there, and `page` or `none` sends the line on. ADR 0079's amendment (ADR 0096): Media Ops are on the Appliance Card first and the page card still offers them, unchanged.

## The change

`e2e/pageMusic.e2e.test.ts` only. The exact diff is in `pageMusic-80.patch`; it leaves line 97's test as it is.

1. **Script** (line 56): `readingOf('loop the song', 'media-loop')`, `readingOf('the song should stop repeating', 'page')`, `readingOf('the song should stop repeating', 'unloop-1')`. Keep the other entries as line 97's fix leaves them. Update the comments on lines 13–14 and 55, which the patch does not touch: the line reads on the Appliance Card, and the media ref's ops are the page card's.
2. **This test, now the Appliance road.** Add `not a command` to its pattern. Expect `loop [0]: loop on`. The ask's state has `^Playing: "Fixture Song - YouTube" playing 0:\d\d/1:00 volume 100% loop off$` and no `[n] ` ref line. Its options include `media-loop`, `media-restart`, `media-pause`, `show`, `play`, `page`, and not `loop`, `restart`, `pause`, `loop-1`. The record is `reading: 'jev'`, `card: 'appliance'`, `verb: 'media'`, `target: null`, `mediaOp.op: 'loop'`, `ended: 'terminal'`. Keep `facts().loop === true` and the unchanged `paneUrl`. Reword the title to say the line is read on the Appliance Card, keeping #362 and #372.
3. **A new test right after it, the page road, holding the assertions this test had on the page card.** `the song should stop repeating` prints `unloop [1]: loop off`. The ask has `kind: 'command'`, the `Playing:` line, and `^\[1\] media "Fixture Song - YouTube" playing 0:\d\d/1:00 volume 100% loop on$`. Its options include `unloop-1`, `restart-1`, `pause-1`, `show`, `play`, and not `unloop`, `restart`, `pause`. The record is `card: 'page'`, `target: 1`, `appliance.chose: 'page'`, `mediaOp.op: 'unloop'`, `ended: 'terminal'`. Assert `facts().loop === false` and the unchanged `paneUrl`.

Do not set `BINGBONG_APPLIANCE_CARD=off`, and do not make the stand-in translate labels: either would prove a road the app does not ship by default.

## Acceptance criteria

- [ ] Both tests pass with the Appliance Card on, in a whole-file run.
- [ ] Each asserts `video.loop` on the element and the unchanged address, not only the CLI line.
- [ ] The Appliance-road test asserts `card: 'appliance'`, `target: null` and no ref on the ask.
- [ ] The page-road test asserts the `[1] media …` state line, the ops by ref, `target: 1` and `appliance.chose: 'page'`.
- [ ] The commit names the reason: the expectation went out of date with #485.
- [ ] No file under `src/` changes.

## Not in this issue

- **Line 97's test (`start it from the beginning`) stays red under this patch.** Its record reads the same (`appliance: malformed`, `failed`), but it has its own finding, `pageMusic-97`.
- **Run alone, this test's rewrite stays red by design.** It needs the first test's `navigate`, as the file's tests have always shared that state. Unchanged alone it is red on a pane nothing has navigated, with the same record (`appliance: malformed`, `failed`); the patched one needs the first test beside it. No test in this file starts from its own page.
- **The page-road script assumes Jev picks `page`.** A real model may read `the song should stop repeating` as `media-unloop`. A green test says the page road works, not that a model takes it, and the line was written for the road, not drawn from the asks log. It adds no corpus case and measures no card.
- **The last test's script entry is unused.** `show the video` is read by the Local Match (`reading: 'local_match'`, `verb: 'play'` on the record), so `readingOf('show the video', 'show')` is never consumed. That test passes; this is not a bug in this issue.
- `#518`'s own open point, the two-video line, is unaffected.

## Dependencies

No `Blocked by` edge. #518 changes a different file, so neither waits on the other. Issues read: the open list in `open.txt` (#518, #517, #516, #512, #490, #469, #452, #439, #415), #518 and #485. None bears on this.

## Grill

`grill-with-docs` is not in this session's skill list. I loaded `grilling`, and did not load `domain-modeling` because nothing here touches the glossary. Answers are mine, from the sources cited.

- **App or test?** Test. CONTEXT.md "Appliance Card" and ADR 0079's amendment say this is the road, and the probe shows the op lands: `loop [0]: loop on`, `video.loop` true, address unchanged, one ask.
- **Does the test guard behaviour the app has lost?** No. Everything it guarded is still there, and both roads are shown working above. `[1]` becomes `[0]` because an Appliance Card op reaches its element by kind (`applianceMediaOp`, `createCdpBrowserController.ts`), as #518 found.
- **Is anything lost if the test only moves to the Appliance Card?** Yes: the Player-less media ref's state line and ops on the page card, since that card has no refs. #518 keeps a `[n] media` check on a native two-video page, but not the YouTube-address page with a `#movie_player` video, whose ref this file alone covers. Hence the second test.
- **Where does the new test go?** Right after this one, because it reads `loop on`, which this test sets, and it puts the loop back off, so the later tests find the video as they did at `7f1eab55`.
- **Why `unloop-1` and that wording?** It needs a line no grammar reads, which the run shows it is (`reading: 'jev'`), and an op that proves the state on the ref was read. Which op is test shape, decided by the code beside it (`idleMusic-111` makes the same choice).
- **Is there a tie to measure?** No. It is test shape, and nothing the owner would feel changes.
- **Does it add a stage, wait, word or sentence?** No, so no Tier change and no UI principle applies.
- **Chart?** Not affected: test only.
- **Should `HANDOFF.md` go?** It is main's own tracked file from `bfd8b13e`, not a handoff from an agent on this test, so it stays. This branch had no handoff commit to verify, and the diagnosis was done from the start.
