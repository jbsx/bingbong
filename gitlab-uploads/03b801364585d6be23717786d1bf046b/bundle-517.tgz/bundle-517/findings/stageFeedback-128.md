---
test: e2e/stageFeedback.e2e.test.ts:128
slug: stageFeedback-128
status: confirmed
class: flake
cause_key: the test reads the Feed once, right after the pill changes, in another renderer that gets each event after the dashboard; since #485 an exact line fires so soon after submit that the read lands 2–7 ms before the line
same_as: none
---

# `stageFeedback` reads the panel's Feed once, the moment the dashboard's pill changes, and since #485 that read beats the line by a few ms

Part of #517.

**Verdict: the test is wrong and the app is right.** The Feed shows `Opening 127.0.0.1`, the same words as the pill, 5–11 ms after the pill. The test looks once, about 4 ms after the pill, and fails on what it sees at that instant. This is a race and not a words problem, so #517's lead about stage words does not apply to this test. Test change only; no file under `src/` changes.

**Scenario:** open a site or page by name, yield 10, state `partly` (`docs/agents/yield.md`, rerun 2026-10-24 on main 20f843b5). No change to the scenario or to what the owner sees. It restores the e2e guard on the narrated wait of a navigate, which has failed at random since 2026-10-27. Nobody can trust a red from it today.

## Root cause

1. The pill and the Feed line live in two renderers. The test polls the pill in the dashboard (`e2e/stageFeedback.e2e.test.ts:119-122`, every 50 ms), then reads the Feed line in the panel's overlay with one `overlayEval` and no wait (`:127-128`). This one-shot read came in with the test, at `cc06d5bc` (#438, 2026-10-26).
2. Main sends each event to the dashboard first and the overlay second (`src/main/session/windowEventPublisher.ts:45-46`, whose comment says "in that order"). So the pill is always ahead of the line, by design. Measured below: 5–11 ms.
3. The harness submits and returns at once (`e2e/scripts.ts:26-27`), so the test's polling starts right after submit.
4. Since `a2297959` (#485, 2026-10-27) an exact line fires with no collect (`src/main/run/commandRunner.ts:1338`; the commit message says "never a collect"). That is what `docs/agents/reliability.md` rule 1 asks for. From `cc06d5bc` to `a2297959`, `Thinking…` to `Opening…` went from 11–13 ms to 4–7 ms, and the test's read went from about 43 ms after the pill to about 4 ms after it.
5. Before that commit the read came about 43 ms after the pill. That fits a first poll that just missed the pill and a second one 50 ms later, by when the line was long in; I inferred this from the numbers and the 50 ms interval and did not trace each poll. The margin the test relied on was never promised, and a real speed-up removed it.

The first thing that is actually wrong is link 1: a single read of a value another renderer gets later. Links 2 and 4 are the app doing what its rules say.

## Evidence

All at `c35c75b1` under Xvfb unless a sha is named. The failure is the same as #517's at `4ba056aa`, on the same line: `expected [ 'Thinking' ] to include 'Opening 127.0.0.1'`. `navigate <url>` is an exact line, so no ask is made; nothing reached a real host or Jev.

**Reproduction, unchanged test**

| Run | Red |
|---|---|
| Alone (`-t 'slow navigate'`), before the probe | 4 of 4 |
| Alone, after reverting the probe | 3 of 3 |
| Whole file | 1 of 3 |

Why the whole file goes red less often is not explained. The other two tests in the file passed in all these runs. Siblings saw the same scatter: `idle-221` 2 red of 4, `appOps-65` 3 red of 4.

**What the app did.** Page-side `MutationObserver` stamps in both renderers (`Date.now()`), relative to the pill reading `Opening…`:

| Run | `Thinking…` pill | Test sends its read | Feed line lands | Test saw the line |
|---|---|---|---|---|
| 1 | −4 ms | +4 | +11 | no |
| 2 | −4 ms | +4 | +6 | no |
| 3 | −4 ms | +4 | +7 | no |
| 4 | −4 ms | +8 | +5 | yes |

Whichever comes first, the read or the line, decides the run. The line was in the overlay in all 4 runs, and the overlay was `visible`.

**The commit that tightened it.** Bisected first-parent over the 139 commits `cc06d5bc..a2297959`, using the probe above, 3 runs a step except where noted:

| Commit | Read after the pill | Red |
|---|---|---|
| `cc06d5bc` (4 runs) | 42–45 ms | 0 of 4 |
| a1a470bb, 5bac5c09, 5ac6be8a, aa04aa2a, cce20e3b, 49d3047d, 4ef86a1b | 37–45 ms | 0 of 21 |
| `7f1eab55`, the commit before #485 | 42–44 ms | 0 of 3 |
| `a2297959`, #485 (4 runs) | 4–10 ms | 2 of 4 |

**The flip.**

| Change | Result |
|---|---|
| The patch, alone | green 5 of 5 |
| The patch, whole file | all 3 tests green, 3 of 3 |
| Patch reverted, alone | red 3 of 3, the same assertion |
| The patch, with the app broken on purpose (`feedProjection.ts:294` drops the stage's words) | red 1 of 1 at `:128`, `waitFor timed out after 1000ms`; so the guard still catches wrong words |

**No arms were built.** The one other design, sending to the overlay first, changes the app to suit a test, and would only move the race to any test that reads the other way. No ruling is needed and the owner would feel no difference.

## The change

In `e2e/stageFeedback.e2e.test.ts`, test `a slow navigate says "Loading…"…`, replace the one-shot read and its `toContain` (`:127-128`) with this. Everything else stays, including `:129`, which reads `lines`:

```ts
// The panel is its own renderer and main sends it each event after the dashboard, so the line lands just after the pill.
const lines = await waitFor(async () => {
  const shown = await harness.overlayEval<string[]>(`Array.from(document.querySelectorAll('.feed-entry--stage .feed-text')).map((el) => el.textContent)`)
  return shown.includes('Opening 127.0.0.1') ? shown : undefined
}, { timeoutMs: 1_000, intervalMs: 20 })
```

The diff is `stageFeedback-128.patch`. It leaves no new stage, wait, word or sentence in the app, so no UI principle or Tier changes, and the input-to-output chart is not affected.

## Acceptance criteria

- [ ] `a slow navigate…` passes alone 5 of 5 and in the whole file 3 of 3, on the road the app ships, with no env switch.
- [ ] It still requires the exact line `Opening 127.0.0.1`, so a Feed with other words fails it.
- [ ] The wait is bounded at 1 s, not the 5 s of the capsule waits beside it.
- [ ] No file under `src/` changes.
- [ ] The commit names the reason: the one read raced the overlay, and #485 removed the margin that hid it.

## Not in this issue

- The test's title says `"Loading…"`, but its body expects `Opening…`, on purpose (`:118`). It has been so since `cc06d5bc`. Left alone so the title still matches #517's table.
- `fixtures/failed-lines/` gets no entry: no line failed to do what was meant.

## Dependencies

No `Blocked by` edge. Read: #517 and #518, the only open issues in `open.txt`. #518 is a different cause.

## Grill

**The `grill-with-docs` skill was not run.** The tool refuses it ("reserved for explicit user invocation"), and I did not rebuild it from its parts. These are the questions a builder would otherwise face, answered from the sources named. They have not been through the skill.

- **App or test?** Test. `windowEventPublisher.ts:33-38` sets the order, and the fire with no collect is reliability.md rule 1 and #485's commit message. No ruling promises the two renderers change in the same instant.
- **Does a late Feed break the Receipt?** No. Principle 1 (`docs/agents/ui.md`) gives 100 ms for the words heard, and the stage line lands within 11 ms of the pill.
- **Why 1 s and not 5 s?** The test's point is that the Feed says what the pill says, so the bound stays tight: about 90 times the worst lag measured here (11 ms), which leaves room for 3 runs sharing the machine. It is the test's own bound, not a product promise, and no scenario changes with it, so it is not a tie.
- **Should the test assert the lag in ms?** No. This machine shares 3 capture slots, so a ms bound would be a new flake, and no rule sets one.
- **Should `:129`'s negative check also wait?** No. It reads the same `lines`, and it only needs them to contain the words already found.
- **Does the waitFor swallow a useful failure message?** Partly: a failure now reads `waitFor timed out` and not the received lines. Accepted, as the mutation run still fails on the right line and the file uses this form throughout.
