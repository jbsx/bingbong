---
test: e2e/upload.e2e.test.ts:133
slug: upload-133
status: confirmed
class: stale-test
cause_key: since #485 a line the Local Match cannot settle is asked on the Appliance Card first, so a decisionScript in page-card labels has its entry consumed by the Appliance Card ask, which reads malformed
same_as: upload-103
---

# e2e/upload still scripts the page card: the "field reopens after an unanswered chooser" proof for `upload-103`, and the test proves that claim only after the cv test has run

Part of #517. Same cause and same change as `upload-103`, whose body stands. This file holds the proof for line 133 and the one thing this test adds. The test is out of date and the app is right: with the script corrected, a field whose chooser was left unanswered opens again and takes the file, as ADR 0092 says ("An unanswered chooser is dropped, and the field still reopens").

This test has a second weakness that the shared script change does not fix. The unanswered chooser its title names is left behind by the cv test. Alone, or with the cv line not clicking, the test goes green without ever passing through that state. The sharper mutant below proves it.

**Scenario:** as `upload-103`: no upload row on the Yield list, nearest `goal` (yield 4, `partly`, `pnpm goal:gate` 2026-10-27). No change to any scenario or its state. It restores the e2e guard on reopening a field after an unanswered chooser (#424, ADR 0092), which has guarded nothing since #485.

## Reproduction

All at `c35c75b1` under Xvfb on the scripted stand-in, except the two base runs. Nothing reached a real host: the suite sets `BINGBONG_DECISION_SCRIPT`, and every ask for these lines records `"model":"scripted"`. The failure is the same as #517's at `4ba056aa`: line 133, `waitFor` timeout of 20000 ms. Line 133 waits in `cli()` for `/^(clicked \[1\]|error:)/`, and the app never prints either.

Kept-log runs carried a throwaway log copy in `afterAll`. It is not in the patch. "Shared fix" is `upload-126.patch`; "self-contained" is that plus this file's change.

| Run | Whole file | Alone (`-t 'left unanswered'`) |
|---|---|---|
| Unchanged | red 1 of 1 (4 failed, 1 passed) | red 1 of 1 |
| Shared fix | green 2 of 2 (5 passed) | green 2 of 2 |
| Shared fix, only this line's `page` entry removed | red 1 of 1 (**this test alone red**, 4 passed) | red 1 of 1 |
| Self-contained | green 2 of 2 (5 passed) | green 2 of 2 |
| Saved patch, log copy removed | green 1 of 1 (5 passed) | green 1 of 1 |

No flake: every run went the way its script predicts. `pnpm typecheck` and eslint on the patched file report no errors.

**Start of the failure, unchanged test built at each commit, alone:**

| Commit | Result |
|---|---|
| `7f1eab55` (parent of #485) | passed |
| `a2297959` (#485) | failed, 20 s timeout |

## What the app did on this line

The chain is `upload-103`'s, read here from this line's own records. These are from the whole-file run; the alone run differs only in its ask id (`cli-2-…`).

1. The Appliance Card ask takes the line's entry 1, `click-1`, and reads `malformed`.
2. The page card ask takes entry 2, the one meant for the Shelf: `action: none`.
   `{"reading":"jev","verb":"none","card":"page","ask":"cli-5-mvvc7qd4","appliance":{"ask":"cli-5-mvvc7qd4-appliance","jev":{"reason":"malformed"}}}`
3. A hop-0 `none` asks again (ADR 0082). That `-where` ask finds the script empty and the line ends `unavailable`.
   `{"reading":"best_guess","verb":"none","ask":"cli-5-mvvc7qd4-where","jev":{"reason":"failed"},"ended":"unavailable"}`
4. Nothing was clicked. The asks for the line are `appliance`, `command`, `where`, with no `shelf`, and no ask carries `fate`.

With the fix the records read as below, with asks `appliance`, `command`, `shelf` for each line:
`{"transcript":"attach the contract","verb":"click","card":"page","target":1,"ended":"terminal","upload":{"file":null,"reason":"none","shelf":3}}`
`{"transcript":"put the notes on it instead","verb":"click","card":"page","target":1,"ended":"terminal","upload":{"file":"notes.txt","shelf":3}}`

**Why the test and not the app:** ADR 0096 rules the Appliance Card first. The road past it, reopening included, is unchanged, as the green runs show.

## What this test adds to `upload-103`'s change

The shared script change is necessary, including `readingOf(LINES.again, 'page')`. It is not enough. Once it lands, this test still gets its unanswered chooser from the cv test, and nothing checks that one was left.

To test the guard I built a throwaway mutant in `createCdpBrowserController.ts`: a chooser that was taken and not answered by `attachFiles` never opens again on that field. It is exactly the behaviour the title rules out, and an answered field still reopens.

| Run | Shared fix | Self-contained |
|---|---|---|
| Mutant, whole file | red (this test alone, 4 passed) | red (this test alone, 4 passed) |
| Mutant, alone | **green: the regression goes unseen** | red |
| Cv line's `page` entry removed, no mutant, whole file | this test green though the cv line never clicked, cv test red | this test green on its own unanswered chooser, cv test red |

Each row is 1 of 1. A blunter mutant, refusing any second chooser on a field, gave the same split: shared fix red whole file and green alone, self-contained red both ways. It also turned the cv test red, which is why the sharper one is the one to read.

So the test passes on the state another test left. Make it leave its own. Patch: `findings/upload-133.patch`. It applies alone on `c35c75b1` and contains all of `upload-126.patch` plus the edits below, so a builder applies this one instead of the other three.

In `e2e/upload.e2e.test.ts`:

- `LINES` gains `left: 'attach the contract'`, before `again`. The Shelf holds no contract, so `none` is the honest reading.
- In `decisionScript`, before the `again` entries, add `readingOf(LINES.left, 'page')`, `readingOf(LINES.left, 'click-1')` and `readingOf(LINES.left, 'none', { file: 'none' })`.
- The test's body becomes:

```ts
await cli(harness, LINES.left, /^(clicked \[1\]|error:)/)
expect(await recordOf(LINES.left)).toMatchObject({ ended: 'terminal', upload: { file: null, reason: 'none', shelf: 3 } })
await cli(harness, LINES.again, /^(clicked \[1\]|error:)/)
expect(await recordOf(LINES.again)).toMatchObject({ ended: 'terminal', card: 'page', appliance: { chose: 'page' }, upload: { file: 'notes.txt', shelf: 3 } })
expect((await changes()).at(-1)).toEqual({ id: 'doc', names: ['notes.txt'] })
expect(chooserWindows()).toEqual([])
```

No file under `src/` changes. No stage, wait, word or sentence is added, so no Tier, UI or chart change applies. The input-to-output flow does not change.

## Acceptance criteria to add

- [ ] This test passes with the Appliance Card on, whole file and alone.
- [ ] It leaves its own unanswered chooser and asserts it (`file: null`, `reason: 'none'`) before the next line, so it no longer relies on the cv test.
- [ ] It asserts the Appliance Card's `page` pick, the page card's click, `notes.txt` on the `doc` field, and no OS dialog.
- [ ] With a throwaway change that stops a field reopening after an unanswered chooser, this test goes red alone as well as whole file. The change is not committed.

## Not in this issue

- `attach the contract`, like `attach a photo of me` and `put the notes on it instead`, has no corpus case, so the scripted readings say nothing about what a real model picks. A case has to come from a real line, so none is built here.

## Dependencies

No blocking edges. I read the open issues on 2026-10-30 (#518, #517, #516, #512, #490, #469, #452, #439, #415): none blocks this.

## Grill

The named `grill-with-docs` skill is not available in this session. I loaded `mattpocock-skills:grilling` and answered its questions myself, as the brief says.

- **Is the shared cause proven here, or inherited?** Proven here: this line's records, the base pair built and run alone, and a flip that turns only this test red.
- **Does the test guard what its title says once the script is fixed?** Whole file yes, alone no: the mutant goes unseen alone. And in the whole file it depends on the cv line having clicked, shown by the cv-removed row.
- **Is the app's reopening itself at fault?** No. It is green on the shipped code with the cv line, and with the test's own line, in front of it. ADR 0092 and `0b29a2a0` ("a field whose chooser was left unanswered (none) opens again") say this was meant.
- **Own line, or assert that the cv record exists?** Own line. An assert on the cv record would time out alone, and this issue requires green alone.
- **Reuse `LINES.cv` for the own line?** No. `recordOf` returns the first record for a transcript, so a repeated line would read the cv test's record.
- **Must the cv test change?** No. `upload-126`'s asserts stand, and the two tests no longer share state beyond the page.
- **Does the extra line lengthen the test past its 30 s limit?** No. The whole file takes about 5 s.
- **Should the said line be asserted here too?** No. The invoice and cv tests hold both sentences, and this title promises the file set.
- **Does a tie need measuring?** No. This is a test's shape, and nothing here changes what the owner hears or how fast. The two arms were still run, above, and self-contained is the only one that catches the mutant alone.
- **Is `HANDOFF.md` a handoff for this test?** No. The resume brief pointed to it, but the file at the worktree root is the orchestrator's from main (`bfd8b13e`), and no handoff commit sits on this branch. It stays, per the standing rule never to remove it from main.
